(() => {
  const KEY='douyinCleanSettings',form=document.getElementById('settings'),status=document.getElementById('status');
  let state=DYSettings.normalize(null),saving=Promise.resolve(),serial=0,lastSaveStarted=0;
  const groups=[
    ['悬浮导航',[
      ['alwaysUseDock','启用悬浮导航','bool'],['dockPosition','导航位置','select',{left:'左侧',right:'右侧',bottom:'底部'}],
      ['autoHideDock','自动收起','bool'],['halfHideDock','收起一半','bool'],['dockItemsConfig','显示的入口及顺序','items']]],
    ['首页分类',[["homeCategoriesConfig","显示的分类","categories"]]],
    ['视频卡片',[
      ['gridColumns','各窗口宽度下的列数','grid'],['enableVideoPreview','悬停预览播放','bool'],
      ['enableVideoCtrlBarOnVideoCard','显示预览控制条','bool'],['videoCardTitleFontSize','标题字号','select',{xs:'小 · 12px',sm:'较小 · 13px',base:'标准 · 14px',lg:'大 · 16px'}]]],
    ['顶部区域',[
      ['enableTopBar','显示顶部搜索区域','bool'],['otherPageTopBarConfig','顶部显示方式','select',{scroll:'下滚隐藏，上滚浮现',always:'始终显示',hover:'鼠标移到顶部时显示'}]]],
    ['视频播放',[
      ['showVideoPipButton','显示详情页小窗播放按钮','bool'],
      ['customFullscreenWheelVolume','全屏时滚轮调音量','bool'],['fullscreenWheelVolumeStep','每次调节幅度（%）','number']]],
  ];
  const help={alwaysUseDock:'关闭后恢复边缘展开的侧栏。',dockPosition:'可放在左侧、右侧或底部。',autoHideDock:'鼠标靠近导航时展开，与收起一半互斥。',halfHideDock:'保留一半在边缘，鼠标靠近时展开。',dockItemsConfig:'拖动调整顺序，也可用上下箭头；至少保留一个入口。',homeCategoriesConfig:'每个分类都可以独立显示或隐藏。',gridColumns:'按浏览器窗口宽度分别设置，默认全部三列。',enableVideoPreview:'关闭后卡片不再悬停播放。',enableVideoCtrlBarOnVideoCard:'控制预览时的播放和时间等操作区域。',videoCardTitleFontSize:'只调整视频卡片标题。',enableTopBar:'控制顶部搜索区域的显示。',otherPageTopBarConfig:'按你的滚动或鼠标位置显示顶部。',showVideoPipButton:'不影响此前隐藏的卡片预览小窗图标。',customFullscreenWheelVolume:'仅浏览器原生全屏生效，普通列表仍正常滚动。',fullscreenWheelVolumeStep:'范围 1–50%，默认 5%。'};
  function persist() {
    const value=structuredClone(state),ticket=++serial;
    lastSaveStarted=Date.now();
    status.textContent='保存中…';
    saving=saving.catch(()=>{}).then(()=>chrome.storage.local.set({[KEY]:value}));
    saving.then(()=>{if(ticket===serial)status.textContent='已保存，等待抖音页面应用…';}).catch(()=>{if(ticket===serial)status.textContent='保存失败，请重试。';});
  }
  function input(type,value,change,label) {
    const element=document.createElement('input');element.type=type;element.setAttribute('aria-label',label);
    if(type==='checkbox')element.checked=value;else element.value=value;
    if(type==='number'){element.min=1;element.max=label.includes('幅度')?50:12;element.step=1;}
    element.addEventListener('change',()=>change(type==='checkbox'?element.checked:type==='number'?Number(element.value):element.value));return element;
  }
  function change(key,value) {
    const focused=document.activeElement?.getAttribute('aria-label');
    const next={...state,[key]:value};
    if(key==='halfHideDock' && value)next.autoHideDock=false;
    if(key==='autoHideDock' && value)next.halfHideDock=false;
    state=DYSettings.normalize(next);persist();render();
    if(focused)Array.from(form.querySelectorAll('[aria-label]')).find(node=>node.getAttribute('aria-label')===focused)?.focus({preventScroll:true});
  }
  function renderDockOrder(controls) {
    controls.classList.add('dock-order-controls');
    let dragged='';
    const move=(key,to)=>{const order=[...state.dockOrder],from=order.indexOf(key);if(from<0||to<0||to>=order.length||from===to)return;order.splice(from,1);order.splice(to,0,key);change('dockOrder',order);};
    state.dockOrder.forEach((key,index)=>{
      const row=document.createElement('div');row.className='dock-sort-item';row.draggable=true;row.dataset.item=key;
      const handle=document.createElement('span');handle.className='drag-handle';handle.textContent=String(index+1).padStart(2,'0');handle.title='拖动调整顺序';handle.setAttribute('aria-hidden','true');
      const name=document.createElement('label');name.className='dock-sort-name';name.textContent=key;
      name.appendChild(input('checkbox',state.dockItemsConfig[key],v=>change('dockItemsConfig',{...state.dockItemsConfig,[key]:v}),'显示入口 '+key));
      row.append(handle,name);
      for(const [symbol,delta,label]of [['↑',-1,'上移'],['↓',1,'下移']]){
        const button=document.createElement('button');button.type='button';button.textContent=symbol;button.setAttribute('aria-label',label+key);button.disabled=index+delta<0||index+delta>=state.dockOrder.length;
        button.addEventListener('click',()=>move(key,index+delta));row.appendChild(button);
      }
      row.addEventListener('dragstart',event=>{if(event.target.closest('input,button')){event.preventDefault();return;}dragged=key;event.dataTransfer.setData('text/plain',key);event.dataTransfer.effectAllowed='move';});
      row.addEventListener('dragover',event=>{event.preventDefault();row.classList.add('drag-over');});
      row.addEventListener('dragleave',()=>row.classList.remove('drag-over'));
      row.addEventListener('drop',event=>{event.preventDefault();const key=event.dataTransfer.getData('text/plain')||dragged;move(key,index);});
      row.addEventListener('dragend',()=>{dragged='';document.querySelectorAll('.drag-over').forEach(node=>node.classList.remove('drag-over'));});
      controls.appendChild(row);
    });
  }


  function render() {
    form.replaceChildren();
    for(const [heading,items] of groups){
      const section=document.createElement('section'),title=document.createElement('h2');title.textContent=heading;section.appendChild(title);
      for(const [key,label,type,choices] of items){
        const row=document.createElement('div');row.className=['items','categories','grid'].includes(type)?'row row-stacked':'row';row.dataset.setting=key;const left=document.createElement('div'),name=document.createElement('div'),desc=document.createElement('div');name.className='name';name.textContent=label;desc.className='desc';desc.textContent=help[key];left.append(name,desc);row.appendChild(left);
        const controls=document.createElement('div');controls.className='controls';
        if(type==='bool'||type==='color'||type==='number')controls.appendChild(input(type==='bool'?'checkbox':type,state[key],v=>change(key,v),label));
        if(type==='select'){const select=document.createElement('select');select.setAttribute('aria-label',label);for(const [value,text]of Object.entries(choices)){const option=document.createElement('option');option.value=value;option.textContent=text;select.appendChild(option);}select.value=state[key];select.addEventListener('change',()=>change(key,select.value));controls.appendChild(select);}
        if(type==='items')renderDockOrder(controls);
        if(type==='categories')controls.classList.add('category-grid');
        if(type==='grid')controls.classList.add('breakpoint-grid');
        if(type==='categories')for(const [sub,value]of Object.entries(state[key])){const wrap=document.createElement('label');wrap.className='small-label';wrap.textContent=sub;wrap.appendChild(input('checkbox',value,v=>change(key,{...state[key],[sub]:v}),label+' '+sub));controls.appendChild(wrap);}
        if(type==='grid')for(const [sub,value]of Object.entries(state[key])){const wrap=document.createElement('label');wrap.className='small-label';wrap.textContent=type==='items'?sub:({base:'<640',sm:'≥640',md:'≥768',lg:'≥1024',xl:'≥1280',xxl:'≥1536'}[sub])+'px ';wrap.appendChild(input(type==='items'?'checkbox':'number',value,v=>change(key,{...state[key],[sub]:v}),label+' '+sub));controls.appendChild(wrap);}
        row.appendChild(controls);section.appendChild(row);
      }form.appendChild(section);
    }
  }
  document.getElementById('reset').addEventListener('click',()=>{state=DYSettings.normalize(null);persist();render();});
  form.addEventListener('submit',e=>e.preventDefault());
  chrome.storage.onChanged.addListener((changes,area)=>{
    const applied=changes.douyinCleanLastApplied?.newValue;
    if(area!=='local'||!applied||applied.timestamp<lastSaveStarted)return;
    status.textContent=applied.ok?'已保存 · 抖音页面已应用':'已保存，但页面应用失败；请刷新抖音后重试。';
  });
  chrome.storage.local.get(KEY).then(result=>{state=DYSettings.normalize(result[KEY]);render();}).catch(()=>{render();status.textContent='读取失败，当前显示默认值。';});
})();
