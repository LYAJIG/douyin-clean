chrome.action.onClicked.addListener(()=>chrome.runtime.openOptionsPage());
chrome.runtime.onMessage.addListener((message,sender)=>{
  if(message?.type==='OPEN_SETTINGS' && sender.id===chrome.runtime.id)chrome.runtime.openOptionsPage();
});
