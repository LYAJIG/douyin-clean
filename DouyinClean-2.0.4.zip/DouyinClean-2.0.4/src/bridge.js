/* Extension storage is kept in the isolated extension context. */
(() => {
  const KEY='douyinCleanSettings';
  const Settings=globalThis.DYSettings;
  let state=Settings.normalize(null),requestId=0;
  const send=()=>window.postMessage({source:'douyin-clean-extension',type:'SETTINGS',settings:state,requestId:++requestId},location.origin);
  window.addEventListener('message',event=>{
    if(event.source!==window || event.origin!==location.origin || event.data?.source!=='douyin-clean-page')return;
    if(event.data.type==='READY')send();
    if(event.data.type==='SETTINGS_APPLIED' && event.data.requestId===requestId) {
      chrome.storage.local.set({douyinCleanLastApplied:{timestamp:Date.now(),ok:event.data.ok===true,version:'2.0.4'}}).catch(()=>{});
    }
    // This bridge exposes only opening our own settings, no arbitrary privileged operations.
    if(event.data.type==='OPEN_SETTINGS')chrome.runtime.sendMessage({type:'OPEN_SETTINGS'}).catch(()=>{});
  });
  chrome.storage.local.get(KEY).then(result=>{state=Settings.normalize(result[KEY]);send();}).catch(()=>send());
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area==='local' && changes[KEY]){state=Settings.normalize(changes[KEY].newValue);send();}
  });
})();
