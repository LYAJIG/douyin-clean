(() => {
  'use strict';
  if (globalThis.__DY_CLEAN_ACTIVE__) return;
  globalThis.__DY_CLEAN_ACTIVE__ = true;
  let config = DYSettings.normalize(null);


  const STYLE_ID = 'tm-douyin-wide-video-style';
  const TRIGGER_ID = 'tm-douyin-left-edge-trigger';
  const OPEN_CLASS = 'tm-douyin-nav-open';
  const BLOCKED_CLASS = 'tm-douyin-blocked-entry';
  const CLOSE_DELAY = 140;
  const TRIGGER_WIDTH = 14;
  let closeTimer = 0;
  let navigation = null;
  let edgeTrigger = null;
  let observer = null;
  let syncTimer = 0;

  const styleText = globalThis.DY_BASE_CSS;


  function injectStyle() {
    let style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }
    if (style.textContent !== styleText) style.textContent = styleText;
    if (style.getAttribute('data-version') !== '2.0.4') style.setAttribute('data-version', '2.0.4');
  }

  function cancelClose() {
    if (closeTimer) {
      window.clearTimeout(closeTimer);
      closeTimer = 0;
    }
  }

  function openNavigation() {
    if (isVideoDetailView()) { closeNavigation(); return; }
    cancelClose();
    if (navigation) navigation.classList.add(OPEN_CLASS);
  }

  function closeNavigation() {
    cancelClose();
    if (navigation) navigation.classList.remove(OPEN_CLASS);
  }

  function scheduleClose() {
    cancelClose();
    closeTimer = window.setTimeout(() => {
      closeTimer = 0;
      closeNavigation();
    }, CLOSE_DELAY);
  }

  let dockSelection = '';
  let dockSelectionUrl = '';

  function isVideoDetailView() {
    const url = new URL(window.location.href);
    return Boolean(url.searchParams.get('modal_id')) || /^\/video(?:\/|$)/.test(url.pathname)
      || ((url.pathname === '/' || url.pathname === '') && url.searchParams.get('recommend') === '1');
  }

  function currentDockSelection() {
    const url = new URL(window.location.href);
    if (dockSelectionUrl === url.href && dockSelection) return dockSelection;
    let label = '';
    if (/^\/jingxuan(?:\/|$)/.test(url.pathname)) label = '精选';
    else if (url.searchParams.get('recommend') === '1') label = '推荐';
    else if (/\/(follow|following)(?:\/|$)/.test(url.pathname)) label = '关注';
    else if (/\/(friend|friends)(?:\/|$)/.test(url.pathname)) label = '朋友';
    else if (/\/user\/self(?:\/|$)/.test(url.pathname)) label = '我的';
    if (!label) {
      for (const name of ['精选', '推荐', '关注', '朋友', '我的']) {
        const entry = findNativeDockEntry(name);
        const link = entry && (entry.closest('a[href]') || entry.querySelector('a[href]'));
        if (!link) continue;
        const target = new URL(link.href, url.href);
        if (target.pathname === url.pathname && target.search === url.search) { label = name; break; }
      }
    }
    // 站内异步切换到未知路径时保留刚选中的项目。
    dockSelection = label || dockSelection;
    dockSelectionUrl = url.href;
    return dockSelection;
  }


  function isHomeBrowsing() {
    // 同时识别抖音首页和用户实际使用的精选首页，兼容站内跳转。
    const url = new URL(window.location.href);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    const isHome = path === '/' || path === '/jingxuan' || path.startsWith('/jingxuan/');
    // 从首页打开视频详情时，地址通过 modal_id 标记所选视频。
    return isHome && !isVideoDetailView();
  }

  function bindNavigation(nextNavigation) {
    if (!nextNavigation || nextNavigation === navigation) return;

    if (navigation) {
      navigation.removeEventListener('pointerenter', openNavigation);
      navigation.removeEventListener('pointerleave', scheduleClose);
    }

    navigation = nextNavigation;
    navigation.classList.remove(OPEN_CLASS);
    navigation.addEventListener('pointerenter', openNavigation, { passive: true });
    navigation.addEventListener('pointerleave', scheduleClose, { passive: true });
  }

  function hideBlockedEntries() {
    const blockedHeaderLabels = new Set(['壁纸', '充钻石', '客户端', '下载客户端']);
    const candidates = document.querySelectorAll(
      '#douyin-header .phl13lpd, '
      + 'a[data-e2e="alink-item"] > .ei95eJfz, '
      + '.H_3q4RFg, '
      + '.llKF7Y8g, '
      + 'a[href*="related_search"], '
      + '.tsSlqyY1'
    );

    for (const item of document.querySelectorAll('#douyin-navigation .tab-discover')) {
      const row = item.closest('.kCzNsmN5') || item;
      row.classList.add(BLOCKED_CLASS);
    }

    for (const label of candidates) {
      const text = label.textContent.trim();
      const isJingxuanDownload = text === '下载抖音精选';
      const isRecognitionButton = text === '识别画面';
      const isRelatedSearch = label.matches('a[href*="related_search"]');
      const isNextEpisode = text === '下一集' || label.matches('.tsSlqyY1');
      if (!isJingxuanDownload && !blockedHeaderLabels.has(text) && !isRecognitionButton && !isRelatedSearch && !isNextEpisode) continue;

      const target = label.closest(
        '.koGT6lm7, ._OJbAD_I, .y9De0v9x, .oi8cIVOq, '
        + '[role="menuitem"], .semi-dropdown-item, .txmGYPBp, '
        + '.jCEsEIDt, a[href*="related_search"], .tsSlqyY1, .iP7HWAld'
      ) || label;
      target.classList.add(BLOCKED_CLASS);
    }

    // “壁纸”按钮可能由异步模块生成，类名会随版本变化，因此按顶栏中的精确文字兜底处理。
    const header = document.querySelector('#douyin-header');
    if (header) {
      for (const node of header.querySelectorAll('*')) {
        if (node.textContent.trim() !== '壁纸') continue;

        const target = node.closest(
          '.oi8cIVOq, .iLNqted2, [class*="circleButtonWrapper"], [role="button"]'
        ) || node;
        target.classList.add(BLOCKED_CLASS);
      }
    }

    // “识别画面”类名会随版本变化，按播放器内的精确文字再做一次兜底。
    const recognitionNodes = document.querySelectorAll(
      '.txmGYPBp, .llKF7Y8g, '
      + '[data-e2e="feed-video"] span, [data-e2e="feed-video"] div, '
      + '[data-e2e="feed-live"] span, [data-e2e="feed-live"] div'
    );
    for (const node of recognitionNodes) {
      if (node.textContent.trim() !== '识别画面') continue;

      const target = node.closest('.txmGYPBp, [class*="aiScreenshot"], [role="button"]')
        || node.parentElement
        || node;
      target.classList.add(BLOCKED_CLASS);
    }

    // “下一集”按钮同样按文字兜底，避免类名变化后重新出现。
    const nextEpisodeNodes = document.querySelectorAll(
      '.feedbar-new-style span, .feedbar-new-style div, '
      + '[data-e2e="feed-video"] span, [data-e2e="feed-video"] div'
    );
    for (const node of nextEpisodeNodes) {
      if (node.textContent.trim() !== '下一集') continue;

      const target = node.closest('.tsSlqyY1, .iP7HWAld, [class*="next"]')
        || node.parentElement
        || node;
      target.classList.add(BLOCKED_CLASS);
    }
  }

  function createEdgeTrigger() {
    if (!document.body) return;
    if (edgeTrigger && edgeTrigger.isConnected) return;

    edgeTrigger = document.createElement('div');
    edgeTrigger.id = TRIGGER_ID;
    edgeTrigger.setAttribute('aria-hidden', 'true');
    edgeTrigger.addEventListener('pointerenter', openNavigation, { passive: true });
    edgeTrigger.addEventListener('pointerleave', scheduleClose, { passive: true });
    document.body.appendChild(edgeTrigger);
  }

  function hideHomeExtras() {
    const root = document.documentElement;
    if (!root) return;
    const home = isHomeBrowsing();
    root.classList.toggle('tm-douyin-home-browsing', home);

    const mark = (node) => {
      if (node && !node.classList.contains('tm-douyin-home-extra')) {
        node.classList.add('tm-douyin-home-extra');
      }
    };
    if (!home) return;
    const header = document.getElementById('douyin-header') || document.querySelector('header, [role="banner"]');
    if (header) {
      for (const node of header.querySelectorAll('*')) {
        if (node.textContent.trim() !== '投稿') continue;
        // 从文字向上寻找只包含投稿内容的按钮，连同图标和红点隐藏。
        let entry = node;
        while (entry.parentElement && entry.parentElement !== header) {
          const parent = entry.parentElement;
          if (parent.textContent.trim() !== '投稿') break;
          const rect = parent.getBoundingClientRect();
          if (rect.width > 160 || rect.height > 140) break;
          entry = parent;
        }
        mark(entry);
      }
    }

    // 截图中的小型悬浮入口：右下角、含图标，并由固定定位容器承载。
    // 不依赖抖音每次构建都会变化的随机类名。
    for (const icon of document.querySelectorAll('svg, img, [class*="icon"], [role="button"]')) {
      let node = icon.parentElement;
      for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
        if (node.classList.contains('tm-douyin-home-extra')) break;
        // SVG 的 title 等辅助文字不应阻止匹配。
        const text = node.textContent.trim();
        if (text.length > 20) continue;
        const rect = node.getBoundingClientRect();
        if (rect.width < 32 || rect.width > 90 || rect.height < 32 || rect.height > 90) continue;
        if (Math.abs(rect.width - rect.height) > 12) continue;
        const right = window.innerWidth - rect.right;
        const bottom = window.innerHeight - rect.bottom;
        if (right < -2 || right > 100 || bottom < -2 || bottom > 100) continue;
        let fixed = false;
        for (let ancestor = node; ancestor && ancestor !== document.body; ancestor = ancestor.parentElement) {
          if (getComputedStyle(ancestor).position === 'fixed') { fixed = true; break; }
        }
        if (fixed) { mark(node); break; }
      }
    }
  }

  function hidePreviewControls() {
    const url = new URL(window.location.href);
    if (isVideoDetailView() || /^\/(user|live)(\/|$)/.test(url.pathname)) return;
    for (const video of document.querySelectorAll('video')) {
      // 预览图标可能是播放器的兄弟节点，向上定位整张 16:9 卡片。
      let surface = null;
      let firstBox = null;
      for (let node = video.parentElement; node && node !== document.body; node = node.parentElement) {
        const box = node.getBoundingClientRect();
        if (box.width > 950 || box.height > 650 || node.querySelectorAll('video').length > 1) break;
        if (box.width < 180 || box.height < 100) continue;
        if (Math.abs(box.width / box.height - 16 / 9) > 0.3) continue;
        if (firstBox && (Math.abs(box.height - firstBox.height) > 24 || Math.abs(box.width - firstBox.width) > 24)) break;
        if (!firstBox) firstBox = box;
        surface = node;
      }
      if (!surface) continue;
      const box = surface.getBoundingClientRect();
      for (const node of surface.querySelectorAll('svg, img, button, [role="button"], i, span, div')) {
        if (node.classList.contains('tm-douyin-hidden-preview-control')) continue;
        if (node.contains(video) || node.querySelector('input, video')) continue;
        const label = (node.getAttribute('aria-label') || '') + (node.getAttribute('title') || '');
        if (/音量|静音|volume|mute/i.test(label)) continue;
        const r = node.getBoundingClientRect();
        if (r.width < 14 || r.width > 72 || r.height < 14 || r.height > 72) continue;
        if (node.textContent.trim().length > 12) continue;
        const x = (r.left + r.width / 2 - box.left) / box.width;
        const y = (r.top + r.height / 2 - box.top) / box.height;
        const watchLater = x >= 0.86 && x <= 1 && y >= 0 && y <= 0.25;
        const smallWindow = x >= 0.72 && x <= 0.88 && y >= 0.75 && y <= 1;
        if (watchLater || smallWindow) node.classList.add('tm-douyin-hidden-preview-control');
      }
    }
  }

  function hideDetailExtras() {
    const root = document.documentElement;
    if (!root) return;
    const url = new URL(window.location.href);
    const detail = isVideoDetailView();
    root.classList.toggle('tm-douyin-detail-view', detail);
    if (!detail) return;
    const mark = node => node.classList.add('tm-douyin-detail-hidden');
    // 详情页左上角搜索框：隐藏完整边框和按钮，不隐藏关闭视频的叉号。
    for (const input of document.querySelectorAll('input')) {
      if (input.closest('#douyin-header')) continue;
      let entry = input;
      for (let depth = 0; entry.parentElement && depth < 6; depth++) {
        const parent = entry.parentElement;
        const box = parent.getBoundingClientRect();
        if (box.width > 700 || box.height > 140 || parent.querySelector('video')) break;
        if (box.top < 0 || box.bottom > window.innerHeight * 0.22 || box.left < window.innerWidth * 0.06 || box.right > window.innerWidth * 0.6) break;
        entry = parent;
      }
      const box = entry.getBoundingClientRect();
      if (entry !== input && box.width >= 160 && box.height > 20 && /搜索/.test(entry.textContent)) mark(entry);
    }
    // 隐藏已清空箭头后仍残留的右侧胶囊背景，限定为空白窄竖条。
    for (const node of document.querySelectorAll('div, button')) {
      if (node.textContent.trim() || node.querySelector('video, img, input, a')) continue;
      const box = node.getBoundingClientRect();
      if (box.width < 24 || box.width > 100 || box.height < 70 || box.height > 230) continue;
      if (box.height < box.width * 1.5 || box.left < window.innerWidth * 0.88) continue;
      if (box.top < window.innerHeight * 0.15 || box.bottom > window.innerHeight * 0.78) continue;
      const style = getComputedStyle(node);
      const radius = parseFloat(style.borderTopLeftRadius);
      const round = style.borderTopLeftRadius.endsWith('%') ? radius >= 40 : radius >= box.width * 0.35;
      if (!round) continue;
      if (node.closest('[data-e2e="comment-list"], #merge-all-comment-container')) continue;
      mark(node);
    }
    const labels = new Set(['听抖音', '倍速']);
    const controls = [
      '[data-e2e="video-player-digg"]', '[data-e2e="video-player-like"]',
      '[data-e2e="video-player-collect"]', '[data-e2e="video-player-more"]',
      '[data-e2e="video-player-watch-later"]', '.xgplayer-playbackrate',
      '.xgplayer-watch-later', '[class*="watchLater"]', '[class*="WatchLater"]',
      '[aria-label="点赞"]', '[aria-label="取消点赞"]',
      '[aria-label="收藏"]', '[aria-label="取消收藏"]',
      '[aria-label="更多"]', '[aria-label*="稍后再看"]', '[title*="稍后再看"]'
    ].join(',');
    for (const node of document.querySelectorAll(controls)) {
      if (node.closest('#douyin-header, #douyin-navigation, [data-e2e="comment-list"], #merge-all-comment-container')) continue;
      let entry = node;
      // 将按钮附带的计数一并隐藏，但不跨到整列操作栏。
      for (let depth = 0; entry.parentElement && depth < 3; depth++) {
        const parent = entry.parentElement;
        const box = parent.getBoundingClientRect();
        if (box.width > 180 || box.height > 240 || parent.querySelector('video')) break;
        if (parent.querySelectorAll('button, [role="button"]').length > 1) break;
        // 不吞掉包含其他独立操作图标的容器。
        if (parent.querySelectorAll('svg').length > 1) break;
        entry = parent;
      }
      mark(entry);
    }
    for (const node of document.querySelectorAll('span, div, button, a')) {
      if (node.childElementCount > 3 || !labels.has(node.textContent.trim())) continue;
      if (node.closest('#douyin-header, #douyin-navigation, [data-e2e="comment-list"]')) continue;
      let entry = node;
      while (entry.parentElement) {
        const parent = entry.parentElement;
        const box = parent.getBoundingClientRect();
        if (parent.textContent.trim() !== node.textContent.trim() || box.width > 180 || box.height > 240) break;
        entry = parent;
      }
      mark(entry);
    }
    for (const input of document.querySelectorAll('input[placeholder*="弹幕"], textarea[placeholder*="弹幕"], [contenteditable="true"][data-placeholder*="弹幕"]')) {
      let entry = input;
      for (let depth = 0; entry.parentElement && depth < 5; depth++) {
        const parent = entry.parentElement;
        const box = parent.getBoundingClientRect();
        if (box.width > 650 || box.height > 110 || parent.querySelector('video')) break;
        if (/连播|清屏|倍速/.test(parent.textContent)) break;
        entry = parent;
      }
      mark(entry);
    }
    // 三点图标兜底，仅定位播放器右侧的独立“更多”入口。
    for (const svg of document.querySelectorAll('svg')) {
      const circles = svg.querySelectorAll('circle');
      if (circles.length !== 3) continue;
      const ys = Array.from(circles, c => Number(c.getAttribute('cy')));
      if (Math.max(...ys) - Math.min(...ys) > 1) continue;
      const box = svg.getBoundingClientRect();
      if (box.width <= 0 || box.left < window.innerWidth * 0.8 || box.top < window.innerHeight * 0.35) continue;
      if (svg.closest('#douyin-header, [data-e2e="comment-list"], #merge-all-comment-container')) continue;
      const parent = svg.parentElement;
      const bounds = parent.getBoundingClientRect();
      if (bounds.width <= 180 && bounds.height <= 100) mark(parent);
    }
  }

  function hideProfileMenuExtras() {
    const labels = new Set(['创作者中心', '我的预约', '我的订单']);
    // 弹窗可能渲染在 body 下，不能只在顶栏内部寻找。
    for (const label of document.querySelectorAll('span, div, a, button, [role="menuitem"]')) {
      const text = label.textContent.trim();
      if (label.childElementCount > 4 || !labels.has(text)) continue;
      if (label.closest('#douyin-navigation, [data-e2e="comment-list"], #merge-all-comment-container')) continue;
      // 向上寻找个人菜单面板，要求同时包含其余个人入口，避免误匹配页面正文。
      let panel = label.parentElement;
      let inProfileMenu = false;
      for (let depth = 0; panel && panel !== document.body && depth < 10; depth++, panel = panel.parentElement) {
        const content = panel.textContent;
        if (content.includes('我的喜欢') && content.includes('我的收藏')
            && content.includes('观看历史') && content.includes('退出登录')) {
          inProfileMenu = true;
          break;
        }
      }
      if (!inProfileMenu) continue;
      let entry = label;
      // 隐藏整行图标与背景；不越过包含其他菜单文字的容器。
      while (entry.parentElement && entry.parentElement !== panel) {
        const parent = entry.parentElement;
        if (parent.textContent.trim() !== text) break;
        entry = parent;
      }
      if (!entry.classList.contains('tm-douyin-profile-hidden')) {
        entry.classList.add('tm-douyin-profile-hidden');
      }
    }
  }

  function hideNavigationExtras() {
    const nav = document.getElementById('douyin-navigation');
    if (!nav) return;
    const labels = new Set(['AI抖音', '直播', '放映厅', '短剧', '小游戏', '反馈', '意见反馈']);
    const nodes = Array.from(nav.querySelectorAll('a, button, span, div, [role="button"]'));
    const mark = node => {
      if (node && !node.classList.contains('tm-douyin-nav-hidden')) node.classList.add('tm-douyin-nav-hidden');
    };
    // 先记录我的与直播之间的区域，定位截图中的无文字活动图案入口。
    const mine = nodes.find(node => node.textContent.trim() === '我的');
    const live = nodes.find(node => node.textContent.trim() === '直播');
    const mineBox = mine && mine.getBoundingClientRect();
    const liveBox = live && live.getBoundingClientRect();
    if (mineBox && liveBox && liveBox.top > mineBox.bottom) {
      for (const image of nav.querySelectorAll('img, svg, [style*="background-image"]')) {
        const box = image.getBoundingClientRect();
        if (box.width < 15 || box.height < 10 || box.top < mineBox.bottom || box.bottom > liveBox.top) continue;
        let entry = image;
        while (entry.parentElement && entry.parentElement !== nav) {
          const parent = entry.parentElement;
          const rect = parent.getBoundingClientRect();
          if (rect.top < mineBox.bottom || rect.bottom > liveBox.top || rect.height > 120) break;
          if (/推荐|关注|朋友|我的/.test(parent.textContent)) break;
          entry = parent;
        }
        mark(entry);
      }
    }
    for (const label of nodes) {
      const text = label.textContent.trim();
      if (!labels.has(text) || label.childElementCount > 4) continue;
      let entry = label;
      while (entry.parentElement && entry.parentElement !== nav) {
        const parent = entry.parentElement;
        if (parent.textContent.trim() !== text) break;
        entry = parent;
      }
      mark(entry);
    }
    // 反馈入口有些版本只有图标，通过可访问名称或链接定位。
    for (const node of nav.querySelectorAll('[aria-label*="反馈"], [title*="反馈"], a[href*="feedback"], [data-e2e*="feedback"]')) {
      mark(node.closest('a, button, [role="button"]') || node);
    }
    // 无名称版本：仅处理最底部独立的文档/反馈图标，不隐藏上方设置和帮助。
    for (const icon of nav.querySelectorAll('svg, img')) {
      const box = icon.getBoundingClientRect();
      if (box.width < 12 || box.width > 50 || box.height < 12 || box.height > 50) continue;
      if (box.top < window.innerHeight - 65 || box.bottom > window.innerHeight + 2) continue;
      let entry = icon;
      for (let depth = 0; entry.parentElement && entry.parentElement !== nav && depth < 3; depth++) {
        const parent = entry.parentElement;
        const rect = parent.getBoundingClientRect();
        if (rect.height > 80 || parent.querySelectorAll('svg, img').length > 1) break;
        if (/设置|帮助/.test(parent.textContent)) break;
        entry = parent;
      }
      mark(entry);
    }
  }

  function hideProfileDownload() {
    const textOf = node => node.textContent.replace(/\s+/g, '').replace(/，/g, ',');
    const targetText = '下载电脑客户端,桌面快捷访问';
    // 精确匹配这条推广文案，兼容标点与空格差异。
    for (const label of document.querySelectorAll('a, button, span, div')) {
      if (label.childElementCount > 4 || textOf(label) !== targetText) continue;
      let entry = label;
      while (entry.parentElement && entry.parentElement !== document.body) {
        const parent = entry.parentElement;
        if (textOf(parent) !== targetText) break;
        // 不隐藏个人信息区域等大型容器。
        const box = parent.getBoundingClientRect();
        if (box.width > 700 || box.height > 180 || parent.querySelector('video, input')) break;
        entry = parent;
      }
      if (!entry.classList.contains('tm-douyin-profile-download-hidden')) {
        entry.classList.add('tm-douyin-profile-download-hidden');
      }
    }
  }

  const DOCK_ICONS = {
    '搜索':'<circle cx="10" cy="10" r="6.5"/><path d="m15 15 6 6"/>',
    '精选': '<rect x="3" y="4" width="18" height="16" rx="4"/><path d="m10 8 6 4-6 4z"/>',
    '通知': '<path d="M5 17h14l-2-3V9a5 5 0 0 0-10 0v5zM10 21h4"/>',
    '消息': '<path d="m3 4 18-1-6 18-4-8zM11 13 21 3"/>',
    '推荐': '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    '关注': '<circle cx="10" cy="8" r="4"/><path d="M3 21v-2a7 7 0 0 1 12-5M17 17h6m-3-3v6"/>',
    '朋友': '<circle cx="9" cy="8" r="3.5"/><path d="M2 21v-2a7 7 0 0 1 14 0v2M16 4a3.5 3.5 0 0 1 0 7m3 4a6 6 0 0 1 3 6"/>',
    '我的': '<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2z"/>',
    '设置': '<path d="m10 3-1 2-3 1-2 3 1 3-1 3 2 3 3 1 1 2h4l1-2 3-1 2-3-1-3 1-3-2-3-3-1-1-2z"/><circle cx="12" cy="12" r="3"/>',
    '刷新': '<path d="M20 7v5h-5M20 12a8 8 0 1 0-2 6"/>'
  };

  function findNativeDockEntry(label) {
    if (label === '精选') {
      return document.querySelector('#douyin-navigation a[href="/jingxuan"], #douyin-navigation a[href^="/jingxuan?"]');
    }
    if (label === '通知' || label === '消息' || label === '我的') {
      const header = document.getElementById('douyin-header') || document.querySelector('header, [role="banner"]');
      if (header) {
        const nodes = Array.from(header.querySelectorAll('a, button, span, div, [aria-label], [title]')).reverse();
        let node = nodes.find(item => {
          const text = item.textContent.trim();
          const name = item.getAttribute('aria-label') || item.getAttribute('title') || '';
          return label === '我的' ? /^(我的|个人中心|用户头像)$/.test(name)
            : (new RegExp('^' + label + '(?:[（(]?\\d+[）)]?)?$')).test(text) || name === label;
        });
        if (!node && label === '我的') {
          const avatar = header.querySelector('[data-e2e*="avatar"], [class*="avatar"], [class*="Avatar"]');
          if (avatar) node = avatar;
          const images = Array.from(header.querySelectorAll('img'));
          node = node || images.find(item => /avatar|头像/i.test((item.className || '') + (item.getAttribute('alt') || '')))
            || images[images.length - 1];
        }
        if (node) {
          let trigger = node.closest('a, button, [role="button"]') || node;
          // 图标文字往往放在带点击处理的共同父节点里。
          while (trigger.parentElement && trigger.parentElement !== header) {
            const parent = trigger.parentElement;
            const rect = parent.getBoundingClientRect();
            if (rect.width > 140 || rect.height > 110 || /通知.*消息|消息.*投稿/.test(parent.textContent)) break;
            trigger = parent;
          }
          return trigger;
        }
      }
    }
    const nav = document.getElementById('douyin-navigation');
    if (!nav) return null;
    const nativeTab = {推荐:'.tab-recommend',关注:'.tab-follow',朋友:'.tab-friend',我的:'.tab-user_self'}[label];
    const known = nativeTab && nav.querySelector(nativeTab + ' a, ' + nativeTab + ' [role="button"]');
    if (known) return known;
    const semantic = Array.from(nav.querySelectorAll('[aria-label], [title]')).find(node =>
      node.getAttribute('aria-label') === label || node.getAttribute('title') === label);
    const text = Array.from(nav.querySelectorAll('a, button, span, div')).reverse().find(node =>
      node.textContent.trim() === label && node.childElementCount <= 3);
    const node = semantic || text;
    if (!node) return null;
    return node.closest('a, button, [role="button"]') || node;
  }

  function syncBewlyDesign() {
    if (!document.body || !document.documentElement) return;
    const url = new URL(window.location.href);
    const detail = isVideoDetailView();
    const nav = document.getElementById('douyin-navigation');
    const enabled = !detail && Boolean(nav) && config.alwaysUseDock;
    document.documentElement.classList.toggle('tm-bewly-layout', enabled);
    let dock = document.getElementById('tm-bewly-dock');
    if (!dock) {
      dock = document.createElement('nav');
      dock.id = 'tm-bewly-dock';
      dock.setAttribute('aria-label', '快捷导航');
      for (const label of ['精选', '推荐', '搜索', '关注', '朋友', '通知', '消息', '我的', '设置']) {
        if (label === '设置') {
          const divider = document.createElement('div');
          divider.className = 'tm-dock-divider';
          divider.setAttribute('aria-hidden', 'true');
          dock.appendChild(divider);
        }
        const button = document.createElement('button');
        button.type = 'button';
        button.dataset.destination = label;
        button.setAttribute('aria-label', label);
        button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + DOCK_ICONS[label] + '</svg>';
        button.addEventListener('click', () => {
          dockSelection = label; dockSelectionUrl = window.location.href;
          for (const item of dock.querySelectorAll('button')) {
            if (item.dataset.destination === label) item.setAttribute('aria-current', 'page');
            else item.removeAttribute('aria-current');
          }
          if (label === '搜索') { openDockSearch(); return; }
          if (label === '设置') { window.postMessage({source:'douyin-clean-page',type:'OPEN_SETTINGS'},location.origin); return; }
          if (label === '精选') { window.location.assign('/jingxuan'); return; }
          const native = findNativeDockEntry(label);
          if (native) {
            // 沿用抖音自己的点击处理，不猜测路由或创建新的账号操作。
            // 打开原生弹层前恢复顶栏，保证附着在顶栏上的弹层可见。
            document.documentElement.classList.remove('tm-bewly-scroll-hidden');
            activateNativeEntry(native, label);
            requestSync();
          }
        });
        dock.appendChild(button);
      }
      document.body.appendChild(dock);
    }
    for (const button of dock.querySelectorAll('button')) {
      const label = button.dataset.destination;
      const native = label === '刷新' ? null : findNativeDockEntry(label);
      // 只呈现当前网站实际提供的入口。
      const available = label === '设置' || ((label === '精选' || label === '搜索' || Boolean(native)) && config.dockItemsConfig[label] !== false);
      if (button.hidden !== !available) button.hidden = !available;
      button.style.setProperty('display', available ? 'grid' : 'none', 'important');
      if (native && ['通知', '消息', '我的'].includes(label)) {
        // 只隐藏原位置的触发内容，原生菜单面板继续由网站管理。
        const triggerBox=native.getBoundingClientRect();
        for (const glyph of native.querySelectorAll('svg, img, span')) {
          const box=glyph.getBoundingClientRect();
          if(box.width<=0||box.height<=0||box.width>70||box.height>55||box.top<triggerBox.top||box.bottom>triggerBox.top+110)continue;
          if (glyph.tagName.toLowerCase() === 'span' && glyph.childElementCount > 0) continue;
          if (glyph.textContent.length > 12) continue;
          glyph.classList.add('tm-bewly-header-original');
        }
        const image = label === '我的' && (native.tagName.toLowerCase() === 'img' ? native : native.querySelector('img'));
        if (image && image.getAttribute('src')) {
          let avatar = button.querySelector('.tm-dock-avatar');
          if (!avatar) {
            button.innerHTML = '';
            avatar = document.createElement('img'); avatar.className = 'tm-dock-avatar';
            avatar.alt = ''; button.appendChild(avatar);
          }
          if (avatar.getAttribute('src') !== image.getAttribute('src')) avatar.setAttribute('src', image.getAttribute('src'));
        }
        if (label === '通知' || label === '消息') {
          const count = native.textContent.match(/\d+/);
          let badge = button.querySelector('.tm-dock-badge');
          if (!badge) { badge = document.createElement('span'); badge.className = 'tm-dock-badge'; button.appendChild(badge); }
          const value = count ? count[0] : '';
          if (badge.textContent !== value) badge.textContent = value;
          badge.hidden = !value || value === '0';
        }
      }
      const active = label === currentDockSelection();
      if (active) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    }
    const ordered=[...config.dockOrder,'设置'].map(label=>dock.querySelector('[data-destination="'+label+'"]')).filter(Boolean);
    const present=Array.from(dock.querySelectorAll('button'));
    if(ordered.some((button,index)=>present[index]!==button)) {
      const focused=document.activeElement;
      for(const button of ordered)dock.appendChild(button);
      if(focused && dock.contains(focused))focused.focus({preventScroll:true});
    }
    if (detail) return;
    const notification = findNativeDockEntry('通知');
    if (notification) notification.classList.toggle('tm-bewly-remove-notification', !config.dockItemsConfig.通知);
    const header = document.getElementById('douyin-header') || document.querySelector('header, [role="banner"]');
    if (!header) return;
    for (const input of header.querySelectorAll('input')) {
      if (input.type !== 'search' && !/搜索/.test(input.getAttribute('placeholder') || '')
          && !/search/i.test(input.getAttribute('data-e2e') || '')) continue;
      let container = null;
      let submit = null;
      for (let parent = input.parentElement, depth = 0; parent && parent !== header && depth < 7; parent = parent.parentElement, depth++) {
        const box = parent.getBoundingClientRect();
        if (box.width > 1200 || box.height > 130) break;
        if (/通知|投稿/.test(parent.textContent)) break;
        const candidates = Array.from(parent.querySelectorAll('button, [role="button"], span, div'));
        const found = candidates.reverse().find(node => node.textContent.trim() === '搜索' && !node.contains(input));
        if (!found) continue;
        container = parent;
        const clickable = found.closest('button, [role="button"]');
        submit = clickable && parent.contains(clickable) ? clickable : found;
        // 包含图标与文字的紧凑父节点才是完整搜索按钮。
        while (submit.parentElement && submit.parentElement !== parent) {
          const next = submit.parentElement;
          if (next.contains(input) || next.textContent.trim() !== '搜索') break;
          const r = next.getBoundingClientRect();
          if (r.width > 180 || r.height > 100) break;
          submit = next;
        }
        break;
      }
      if (container && submit) {
        container.classList.add('tm-bewly-search');
        submit.classList.add('tm-bewly-search-submit');
        if (!submit.getAttribute('aria-label')) submit.setAttribute('aria-label', '搜索');
      }
    }
  }


  const scrollPositions = new WeakMap();
  let scrollRoute = '';
  function resetScrollChrome() {
    document.documentElement.classList.remove('tm-bewly-scroll-hidden');
  }

  let chromeLayoutUntil=0;
  function handleChromeScroll(event) {
    if (config.otherPageTopBarConfig !== 'scroll') return;
    if (!document.documentElement.classList.contains('tm-bewly-layout') || !isHomeBrowsing()) return;
    const source = event.target === document || event.target === window
      ? (document.scrollingElement || document.documentElement) : event.target;
    if (!source || typeof source.scrollTop !== 'number') return;
    // 评论、弹层、侧栏内的滚动不控制首页顶栏。
    if (source.closest && source.closest('#tm-bewly-dock, #douyin-navigation, [role="dialog"], [role="menu"], [data-e2e="comment-list"], #merge-all-comment-container')) return;
    if (source !== document.scrollingElement && source !== document.documentElement && source !== document.body) {
      const box = source.getBoundingClientRect();
      if (box.width < window.innerWidth * 0.5 || box.height < window.innerHeight * 0.4) return;
    }
    const y = Math.max(0, source.scrollTop);
    let state = scrollPositions.get(source);
    if (!state) { state = { previous: 0, anchor: 0, direction: 0 }; scrollPositions.set(source, state); }
    const delta = y - state.previous;
    state.previous = y;
    if (Date.now() < chromeLayoutUntil) { state.anchor=y; return; }
    if (y < 35) { state.anchor = y; state.direction = 0; resetScrollChrome(); return; }
    if (Math.abs(delta) < 0.5) return;
    const direction = delta > 0 ? 1 : -1;
    if (direction !== state.direction) { state.direction = direction; state.anchor = y - delta; }
    if (Math.abs(y - state.anchor) < 12) return;
    const focused = document.activeElement;
    if (focused && focused.closest && focused.closest('.tm-bewly-search')) return;
    const hide = direction > 0;
    if (document.documentElement.classList.contains('tm-bewly-scroll-hidden') !== hide) {
      chromeLayoutUntil=Date.now()+230;
      document.documentElement.classList.toggle('tm-bewly-scroll-hidden',hide);
    }
    state.anchor = y;
  }

  function syncScrollChrome() {
    if (!document.documentElement) return;
    if (scrollRoute !== window.location.href) {
      scrollRoute = window.location.href;
      resetScrollChrome();
    }
    const enabled = config.otherPageTopBarConfig === 'scroll' && isHomeBrowsing() && document.documentElement.classList.contains('tm-bewly-layout');
    if (!enabled) { resetScrollChrome(); return; }
    const header = document.getElementById('douyin-header') || document.querySelector('header, [role="banner"]');
    if (header) header.classList.add('tm-bewly-scroll-chrome');
    // 从可见分类标签向上寻找完整的横向分类栏，包含可能吸顶的背景。
    for (const label of document.querySelectorAll('a, span, button, div')) {
      if (!['全部', '公开课', '游戏', '音乐', '美食', '知识', '生活vlog'].includes(label.textContent.trim())) continue;
      if (label.childElementCount > 3 || label.closest('#douyin-header, #douyin-navigation, #tm-bewly-dock, article, [data-e2e="feed-item"]')) continue;
      let bar = null;
      for (let node = label.parentElement, depth = 0; node && node !== document.body && depth < 6; node = node.parentElement, depth++) {
        const box = node.getBoundingClientRect();
        if (box.height > 150) break;
        const content = node.textContent;
        if (['全部', '公开课', '游戏', '音乐', '美食', '知识'].filter(text => content.includes(text)).length >= 3) bar = node;
      }
      if (bar) bar.classList.add('tm-bewly-scroll-chrome');
    }
  }


  function activateNativeEntry(native, label) {
    // 优先调用实际交互节点的 React 处理函数，避开仅用于展示文字的父容器。
    const candidates = [native, ...native.querySelectorAll('*')];
    for (let parent = native.parentElement, depth = 0; parent && depth < 3; parent = parent.parentElement, depth++) {
      if (parent.id === 'douyin-header' || parent.id === 'douyin-navigation') break;
      candidates.push(parent);
    }
    const eventFor = node => ({
      type: 'click', target: node, currentTarget: node, button: 0,
      bubbles: true, isTrusted: false, defaultPrevented: false,
      nativeEvent: new MouseEvent('click', { bubbles: true, view: window }),
      preventDefault() { this.defaultPrevented = true; }, stopPropagation() {},
      persist() {}, isPropagationStopped: () => false, isDefaultPrevented() { return this.defaultPrevented; }
    });
    const props = candidates.map(node => ({node, value: Object.keys(node)
      .filter(key => key.startsWith('__reactProps$')).map(key => node[key])[0]})).filter(item => item.value);
    const click = props.find(item => typeof item.value.onClick === 'function');
    if (click) { click.value.onClick(eventFor(click.node)); return; }
    if (label === '我的' || label === '通知' || label === '消息') {
      const hover = props.find(item => typeof item.value.onMouseEnter === 'function' || typeof item.value.onPointerEnter === 'function');
      if (hover) {
        const event = eventFor(hover.node); event.type = 'mouseenter';
        (hover.value.onMouseEnter || hover.value.onPointerEnter)(event); return;
      }
    }
    const target = native.querySelector('button, a, [role="button"]') || native;
    target.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, view: window }));
    target.click();
  }

  const lockedGrids = new WeakMap();
  function lockGrid(grid) {
    let record = lockedGrids.get(grid);
    if (!record) {
      record = { observer: new MutationObserver(() => lockGrid(grid)) };
      lockedGrids.set(grid, record);
    }
    // 写入时暂时断开局部监听，避免自己的样式更新触发重复扫描。
    record.observer.disconnect();
    const apply = (node, key, value) => {
      if (node.style.getPropertyValue(key) !== value || node.style.getPropertyPriority(key) !== 'important') node.style.setProperty(key, value, 'important');
    };
    apply(grid, 'display', 'grid');
    apply(grid, 'grid-template-columns', 'repeat(' + DYSettings.columns(config, window.innerWidth) + ', minmax(0, 1fr))');
    apply(grid, 'gap', '22px 12px');
    const options = { attributes: true, attributeFilter: ['style', 'class'] };
    for (const card of grid.children) {
      if (!card.classList.contains('discover-video-card-item')) continue;
      for (const [key,value] of [['width','auto'],['min-width','0'],['max-width','none'],['grid-column','auto'],['grid-row','auto'],['position','relative'],['left','auto'],['top','auto'],['transform','none']]) apply(card,key,value);
      record.observer.observe(card, options);
    }
    record.observer.observe(grid, { ...options, childList: true });
  }

  function syncCompactGrid() {
    const grids = new Set(document.querySelectorAll('.bigCardWaterfallContainer'));
    // 页面加载后容器名称变化时，从实际卡片的共同父节点重新定位。
    for (const card of document.querySelectorAll('.discover-video-card-item')) {
      const parent = card.parentElement;
      if (parent && Array.from(parent.children).filter(node => node.classList.contains('discover-video-card-item')).length >= 3) grids.add(parent);
    }
    for (const grid of grids) lockGrid(grid);
  }


  function syncMessageLayout() {
    const slider = document.getElementById('slidelist');
    if (!slider) return;
    const panel = slider.querySelector('.QXD5_9V5 .imContainer.isAweme');
    const shell = panel && panel.closest('.QXD5_9V5');
    const box = panel && panel.getBoundingClientRect();
    let open = false;
    if (box && shell) {
      const style = getComputedStyle(shell);
      open = box.width > 160 && box.height > 100 && box.left < window.innerWidth - 30
        && box.right > 30 && style.display !== 'none' && style.visibility !== 'hidden';
    }
    if (open) {
      const width = Math.round(shell.getBoundingClientRect().width || box.width);
      const value = width + 'px';
      if (slider.style.getPropertyValue('--tm-message-width') !== value) slider.style.setProperty('--tm-message-width', value);
    }
    if (slider.classList.contains('tm-message-docked') !== open) slider.classList.toggle('tm-message-docked', open);
  }


  let mainScrollSource = null;
  let edgeFrame = 0;
  function isMainScroller(node) {
    if (!(node instanceof Element) || node.scrollHeight <= node.clientHeight + 4) return false;
    const box = node.getBoundingClientRect();
    return box.width >= window.innerWidth * 0.5 && box.height >= window.innerHeight * 0.35;
  }
  function updateEdgeThumb() {
    const track = document.getElementById('tm-edge-scrollbar');
    if (!track) return;
    const source = mainScrollSource;
    const enabled = isHomeBrowsing() && document.documentElement.classList.contains('tm-bewly-layout');
    track.hidden = !enabled || !source || !source.isConnected || source.scrollHeight <= source.clientHeight + 4;
    if (track.hidden) return;
    const height = track.clientHeight;
    const thumbHeight = Math.min(height, Math.max(30, height * source.clientHeight / source.scrollHeight));
    const range = source.scrollHeight - source.clientHeight;
    const top = (height - thumbHeight) * Math.max(0, Math.min(1, source.scrollTop / range));
    const thumb = track.firstElementChild;
    thumb.style.height = thumbHeight + 'px';
    thumb.style.transform = 'translateY(' + top + 'px)';
    track.setAttribute('aria-valuenow', String(Math.round(100 * source.scrollTop / range)));
  }
  function scheduleEdgeThumb() {
    if (edgeFrame) return;
    edgeFrame = requestAnimationFrame(() => { edgeFrame = 0; updateEdgeThumb(); });
  }
  function syncEdgeScrollbar() {
    if (!document.body) return;
    let track = document.getElementById('tm-edge-scrollbar');
    if (!track) {
      track = document.createElement('div'); track.id = 'tm-edge-scrollbar';
      track.tabIndex = 0; track.setAttribute('role','scrollbar'); track.setAttribute('aria-label','页面滚动');
      track.setAttribute('aria-orientation','vertical'); track.setAttribute('aria-valuemin','0'); track.setAttribute('aria-valuemax','100');
      const thumb = document.createElement('div'); thumb.className = 'tm-edge-thumb'; track.appendChild(thumb);
      let drag = null;
      track.addEventListener('pointerdown', event => {
        if (!mainScrollSource || event.button !== 0) return;
        const t = track.getBoundingClientRect();
        const thumbRect = thumb.getBoundingClientRect();
        drag = { offset: event.target === thumb ? event.clientY - thumbRect.top : thumbRect.height / 2 };
        track.setPointerCapture(event.pointerId); event.preventDefault();
        if (event.target !== thumb) move(event);
      });
      const move = event => {
        if (!drag || !mainScrollSource) return;
        const t = track.getBoundingClientRect();
        const travel = Math.max(1, track.clientHeight - thumb.getBoundingClientRect().height);
        const ratio = Math.max(0,Math.min(1,(event.clientY - t.top - drag.offset)/travel));
        mainScrollSource.scrollTop = ratio * (mainScrollSource.scrollHeight - mainScrollSource.clientHeight);
        scheduleEdgeThumb();
      };
      track.addEventListener('pointermove', move);
      track.addEventListener('pointerup', () => { drag = null; });
      track.addEventListener('pointercancel', () => { drag = null; });
      track.addEventListener('keydown', event => {
        if (!mainScrollSource) return;
        const source = mainScrollSource;
        const positions = {ArrowDown:source.scrollTop+50,ArrowUp:source.scrollTop-50,PageDown:source.scrollTop+source.clientHeight*.85,PageUp:source.scrollTop-source.clientHeight*.85,Home:0,End:source.scrollHeight};
        if (!(event.key in positions)) return;
        event.preventDefault(); source.scrollTop = positions[event.key]; scheduleEdgeThumb();
      });
      document.body.appendChild(track);
    }
    if (!mainScrollSource || !mainScrollSource.isConnected || !isMainScroller(mainScrollSource)) {
      const candidates = Array.from(document.querySelectorAll('.jingxuan-scroll-element, .route-scroll-container, .parent-route-container, #douyin-right-container'));
      if (document.scrollingElement) candidates.push(document.scrollingElement);
      mainScrollSource = candidates.find(isMainScroller) || null;
    }
    if (mainScrollSource) mainScrollSource.classList.add('tm-main-scroll-source');
    updateEdgeThumb();
  }
  document.addEventListener('scroll', event => {
    if (!isHomeBrowsing()) return;
    const source = event.target === document ? document.scrollingElement : event.target;
    if (source !== mainScrollSource && isMainScroller(source)) {
      mainScrollSource = source; source.classList.add('tm-main-scroll-source');
    }
    if (source === mainScrollSource) scheduleEdgeThumb();
  }, {capture:true,passive:true});


  let wheelAttached = false;
  function fullscreenWheel(event) {
    if (!config.customFullscreenWheelVolume || !document.fullscreenElement || event.ctrlKey || event.metaKey || !event.deltaY) return;
    if (event.target instanceof Element && event.target.closest('input, textarea, [contenteditable="true"], [data-e2e="comment-list"]')) return;
    const video = document.fullscreenElement.matches('video') ? document.fullscreenElement : document.fullscreenElement.querySelector('video');
    if (!video) return;
    event.preventDefault();event.stopImmediatePropagation();
    video.volume=Math.max(0,Math.min(1,video.volume+(event.deltaY<0?1:-1)*config.fullscreenWheelVolumeStep/100));
  }
  const previewSelector='.discover-video-card-item, .bigCardQuickPlayerContainer';
  function blockPreview(event) {
    if (config.enableVideoPreview || isVideoDetailView()) return;
    if (event.target instanceof Element && event.target.closest(previewSelector)) event.stopImmediatePropagation();
  }
  for (const name of ['pointerover','mouseover','pointerenter','mouseenter']) document.addEventListener(name,blockPreview,true);
  document.addEventListener('play',event=>{
    if (!config.enableVideoPreview && !isVideoDetailView() && event.target instanceof HTMLVideoElement
      && event.target.closest(previewSelector)) event.target.pause();
  },true);
  function applyConfiguration() {
    const root=document.documentElement;
    if (!root) return;
    const attrs={
      'data-dy-dock-position':config.dockPosition,
      'data-dy-dock-hide':config.autoHideDock?'auto':config.halfHideDock?'half':'none',
      'data-dy-topbar':config.enableTopBar?config.otherPageTopBarConfig:'off',
      'data-dy-preview':config.enableVideoPreview?'on':'off',
      'data-dy-preview-controls':config.enableVideoCtrlBarOnVideoCard?'on':'off',
      'data-dy-pip':config.showVideoPipButton?'on':'off',
    };
    for (const [key,value] of Object.entries(attrs)) if(root.getAttribute(key)!==value) root.setAttribute(key,value);
    const variables={
      '--dy-columns':String(DYSettings.columns(config,window.innerWidth)),
      '--dy-accent':'#35b5d5','--dy-base':'#20212b',
      '--dy-title':({xs:12,sm:13,base:14,lg:16}[config.videoCardTitleFontSize])+'px',
      '--dy-blur':'none',
      '--dy-shadow':'none',
    };
    for (const [key,value] of Object.entries(variables)) if(root.style.getPropertyValue(key)!==value)root.style.setProperty(key,value);
    let style=document.getElementById('dy-clean-settings-style');
    if(!style){style=document.createElement('style');style.id='dy-clean-settings-style';style.textContent=globalThis.DY_CONFIG_CSS;root.appendChild(style);}
    if(config.otherPageTopBarConfig!=='scroll')resetScrollChrome();
    if(wheelAttached!==config.customFullscreenWheelVolume){
      wheelAttached=config.customFullscreenWheelVolume;
      if(wheelAttached)window.addEventListener('wheel',fullscreenWheel,{capture:true,passive:false});
      else window.removeEventListener('wheel',fullscreenWheel,true);
    }
  }
  window.addEventListener('message',event=>{
    if(event.source!==window || event.origin!==location.origin || event.data?.source!=='douyin-clean-extension' || event.data.type!=='SETTINGS')return;
    let ok=false;
    try {
      config=DYSettings.normalize(event.data.settings);
      syncDom();
      if (!config.enableVideoPreview) for (const video of document.querySelectorAll('.discover-video-card-item video, .bigCardQuickPlayerContainer video')) video.pause();
      ok=true;
    } catch(error) { console.error('[Douyin Clean] Settings apply failed',error); }
    window.postMessage({source:'douyin-clean-page',type:'SETTINGS_APPLIED',requestId:event.data.requestId,ok},location.origin);
  });
  window.postMessage({source:'douyin-clean-page',type:'READY'},location.origin);


  function syncCardPresentation() {
    const isTime = text => /\b\d{1,2}:\d{2}(?::\d{2})?\s*\/\s*\d{1,2}:\d{2}(?::\d{2})?\b/.test(text);
    for (const card of document.querySelectorAll('.discover-video-card-item')) {
      const image=card.querySelector('.discover-video-card-img, img');
      if (!image) continue;
      const cover=image.getBoundingClientRect();
      // 真实卡片的标题并不总带 title 类名；按封面下的首段文本定位。
      const walker=document.createTreeWalker(card,NodeFilter.SHOW_TEXT);
      let textNode;
      while ((textNode=walker.nextNode())) {
        const text=textNode.textContent.trim(),node=textNode.parentElement;
        if (!node || text.length<3 || /^@/.test(text) || isTime(text)) continue;
        if (node.closest('script,style,[aria-hidden="true"],.dy-preview-control')) continue;
        const rect=node.getBoundingClientRect();
        if(rect.width<=0 || rect.height<=0 || rect.top<cover.bottom-3 || rect.top>cover.bottom+85)continue;
        if(!node.classList.contains('dy-card-title'))node.classList.add('dy-card-title');
        const size=({xs:12,sm:13,base:14,lg:16}[config.videoCardTitleFontSize])+'px';
        if(node.style.getPropertyValue('font-size')!==size||node.style.getPropertyPriority('font-size')!=='important')node.style.setProperty('font-size',size,'important');
        break;
      }
    }
    // 卡片预览有原生 xg 控件和轻量预览两套实现，后者没有 xgplayer-controls 类。
    for (const surface of document.querySelectorAll('.discover-video-card-item, .bigCardQuickPlayerContainer')) {
      const frame=surface.getBoundingClientRect();
      if(frame.width<=0||frame.height<=0)continue;
      for (const node of surface.querySelectorAll('div,span,p,time,xg-controls')) {
        if(node.childElementCount>3 || !isTime(node.textContent.trim()) || node.querySelector('img,video'))continue;
        let entry=node;
        while(entry.parentElement && entry.parentElement!==surface){
          const parent=entry.parentElement,box=parent.getBoundingClientRect();
          if(box.height>70||box.width>frame.width+2||parent.querySelector('img,video'))break;
          if(box.top<frame.top+frame.height*.55)break;
          entry=parent;
        }
        if(!entry.classList.contains('dy-preview-control'))entry.classList.add('dy-preview-control');
      }
    }
  }


  function openDockSearch() {
    let dialog=document.getElementById('dy-dock-search');
    if(!dialog){
      dialog=document.createElement('dialog');dialog.id='dy-dock-search';
      const form=document.createElement('form'),input=document.createElement('input'),submit=document.createElement('button'),close=document.createElement('button');
      input.type='search';input.name='q';input.setAttribute('aria-label','搜索抖音');input.autocomplete='off';
      submit.type='submit';submit.textContent='搜索';close.type='button';close.textContent='×';close.setAttribute('aria-label','关闭搜索');
      close.addEventListener('click',()=>dialog.close());
      form.addEventListener('submit',event=>{event.preventDefault();const query=input.value.trim();if(query)window.location.assign('/search/'+encodeURIComponent(query));});
      form.append(input,submit,close);dialog.appendChild(form);document.body.appendChild(dialog);
      dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
    }
    if(!dialog.open)dialog.showModal();dialog.querySelector('input').focus();
  }

  function syncNewPreferences() {
    const root=document.documentElement;if(!root)return;
    const detail=isVideoDetailView();
    root.classList.toggle('dy-disable-edge-nav',detail);
    if(detail){cancelClose();if(navigation)navigation.classList.remove(OPEN_CLASS);}
    const url=new URL(location.href),profile=/^\/user(?:\/|$)/.test(url.pathname);
    root.classList.toggle('dy-profile-page',profile);
    for(const bar of document.querySelectorAll('.discover-tab-container .semi-tabs-bar')){
      for(const label of bar.querySelectorAll('span,a,div,button,[role="tab"]')){
        const name=label.textContent.trim();if(!Object.hasOwn(config.homeCategoriesConfig,name)||label.childElementCount>3)continue;
        let entry=label.closest('.semi-tabs-tab,[role="tab"]')||label;
        while(entry.parentElement && entry.parentElement!==bar && entry.parentElement.textContent.trim()===name)entry=entry.parentElement;
        entry.classList.remove('tm-douyin-hidden-category');
        entry.classList.toggle('dy-hidden-category',!config.homeCategoriesConfig[name]);
      }
    }
    // 投稿的隐藏不应只限首页，个人主页也应用。
    const header=document.getElementById('douyin-header');
    if(header){
      for(const node of header.querySelectorAll('span,p,div,a,button')){
        if(node.childElementCount>3||node.textContent.trim()!=='投稿')continue;
        let entry=node;
        while(entry.parentElement && entry.parentElement!==header){
          const parent=entry.parentElement,box=parent.getBoundingClientRect();
          if(parent.textContent.trim()!=='投稿'||box.width>160||box.height>110)break;
          entry=parent;
        }
        entry.classList.add('dy-hide-upload');
      }
      // 不整块删除未知遮罩：仅收起未获得焦点的原生搜索建议面板。
      const input=header.querySelector('input[type="search"],input[data-e2e="searchbar-input"]');
      const searching=input && document.activeElement===input;
      root.classList.toggle('dy-profile-searching',Boolean(searching));
      for(const panel of header.querySelectorAll('[class*="search-suggest"],[class*="searchSuggest"],[class*="SearchSuggest"],[data-e2e*="search-sug"]')){
        if(panel.contains(input))continue;
        panel.classList.toggle('dy-search-suggestion-inactive',profile&&!searching);
      }
      if(profile)for(const layer of header.querySelectorAll('div')){
        if(layer.textContent.trim() || layer.querySelector('input,button,a,select,textarea,img,video,iframe,[role="dialog"],[role="menu"]'))continue;
        const box=layer.getBoundingClientRect();
        if(box.width<250||box.width>innerWidth*.75||box.height<120||box.height>500||box.top< -10||box.top>80)continue;
        const style=getComputedStyle(layer);
        if(!['absolute','fixed'].includes(style.position))continue;
        const painted=style.backgroundImage!=='none'||style.boxShadow!=='none'||!['transparent','rgba(0, 0, 0, 0)'].includes(style.backgroundColor);
        if(painted)layer.classList.add('dy-empty-search-backdrop');
      }
    }
  }


  function syncDom() {
    applyConfiguration();
    injectStyle();
    if (!navigation || !navigation.isConnected) {
      bindNavigation(document.querySelector('#douyin-navigation'));
    }
    if (!edgeTrigger || !edgeTrigger.isConnected) {
      createEdgeTrigger();
    }
    try {
      hideBlockedEntries();
    } catch (_) {
      // 原有屏蔽项失败时，继续处理首页精简。
    }
    hideHomeExtras();
    hidePreviewControls();
    hideDetailExtras();
    hideProfileMenuExtras();
    hideNavigationExtras();
    hideProfileDownload();
    syncBewlyDesign();
    syncScrollChrome();
    syncCompactGrid();
    syncCardPresentation();
    syncNewPreferences();
    syncMessageLayout();
    syncEdgeScrollbar();
  }

  function requestSync() {
    if (syncTimer) return;
    // 整页精简最多每 160ms 一次；三列布局由独立的局部监听即时维护。
    syncTimer = window.setTimeout(() => {
      window.requestAnimationFrame(() => { syncTimer = 0; syncDom(); });
    }, 160);
  }

  function startObserver() {
    if (observer || !document.documentElement) return;
    observer = new MutationObserver(records => {
      syncDetailState();
      const relevant = records.some(record => Array.from(record.addedNodes).some(node =>
        node.nodeType === 1 && !node.closest?.('#tm-bewly-dock, .xgplayer-time, .xgplayer-progress, .danmaku')
      ) || Array.from(record.removedNodes).some(node => node.nodeType === 1 && !/^(SPAN|PATH|SVG)$/.test(node.tagName)));
      if (relevant) requestSync();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function init() {
    injectStyle();
    syncDom();
    startObserver();
  }

  function syncDetailState() {
    if (document.documentElement) document.documentElement.classList.toggle('tm-douyin-detail-view', isVideoDetailView());
  }

  // 在站内路由变化时立即更新详情 CSS，不等待页面节点加载。
  for (const name of ['pushState', 'replaceState']) {
    const original = history[name];
    history[name] = function (...args) {
      const result = original.apply(this, args);
      syncDetailState();
      requestSync();
      return result;
    };
  }
  window.addEventListener('popstate', syncDetailState);
  syncDetailState();

  // 保存运行时布局，仅导出结构、尺寸和有限的界面按钮名称。
  // 不导出私信正文、账号资料、图片地址、Cookie、脚本或输入框内容。
  function exportCurrentLayout() {
    const safeLabels = new Set(['更多', '消息', '私信', '发送', '点赞', '收藏', '倍速', '连播', '清屏', '智能', '听抖音', '稍后再看', '搜索', '评论', '关注', '朋友', '推荐', '精选', '我的']);
    const excluded = new Set(['SCRIPT', 'STYLE', 'LINK', 'META', 'NOSCRIPT']);
    let count = 0;
    function inspect(node) {
      if (excluded.has(node.tagName) || count++ > 18000) return null;
      const box = node.getBoundingClientRect();
      const css = getComputedStyle(node);
      const result = {tag:node.tagName.toLowerCase(), class:typeof node.className === 'string' ? node.className : node.getAttribute('class'),
        rect:[box.x,box.y,box.width,box.height].map(v=>Math.round(v)),
        css:{display:css.display,position:css.position,width:css.width,height:css.height,overflow:css.overflow,
          backgroundColor:css.backgroundColor,backdropFilter:css.backdropFilter,boxShadow:css.boxShadow,visibility:css.visibility,pointerEvents:css.pointerEvents,gridTemplateColumns:css.gridTemplateColumns,padding:css.padding,margin:css.margin,zIndex:css.zIndex,transform:css.transform}};
      const id=node.id;
      if (/^(douyin-|slidelist|root|tm-)/.test(id)) result.id=id;
      for (const attr of ['data-e2e','role']) if (node.getAttribute(attr)) result[attr]=node.getAttribute(attr);
      for (const attr of ['aria-label','title','placeholder']) {
        const label=node.getAttribute(attr);
        if (label && (safeLabels.has(label) || label.includes('弹幕'))) result[attr]=label;
      }
      if (node.children.length===0 && safeLabels.has(node.textContent.trim())) result.label=node.textContent.trim();
      if (['path','circle','rect','line','polyline'].includes(result.tag)) {
        result.svg={};for(const attr of ['d','cx','cy','r','x','y','width','height','x1','y1','x2','y2','points'])if(node.getAttribute(attr))result.svg[attr]=node.getAttribute(attr);
      }
      result.children=Array.from(node.children,inspect).filter(Boolean);
      return result;
    }
    const path=window.location.pathname;
    const mode=isVideoDetailView()?'video':/^\/user(?:\/|$)/.test(path)?'profile':'list';
    const data={version:'2.0.4',styleVersion:document.getElementById(STYLE_ID)?.getAttribute('data-version'),mode,route: mode==='video'?'video-detail':path.startsWith('/jingxuan')?'/jingxuan':'other',
      viewport:[window.innerWidth,window.innerHeight],tree:inspect(document.body)};
    const blob=new Blob([JSON.stringify(data)],{type:'application/json'});
    const url=URL.createObjectURL(blob);const link=document.createElement('a');
    link.href=url;link.download='douyin-layout-'+mode+'.json';link.click();
    window.setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  document.addEventListener('keydown',event=>{
    if(event.altKey && event.shiftKey && event.code==='KeyL'){
      event.preventDefault();exportCurrentLayout();
    }
  });


  window.setInterval(syncMessageLayout, 180);
  injectStyle();
  window.addEventListener('popstate', () => { resetScrollChrome(); requestSync(); });
  document.addEventListener('scroll', handleChromeScroll, { capture: true, passive: true });
  window.addEventListener('resize', requestSync, { passive: true });
  // 悬停时再检查一次，覆盖复用已有播放器、没有新增节点的预览。
  document.addEventListener('pointerover', event => {
    const target = event.target instanceof Element && event.target.closest('.discover-video-card-item, #douyin-header, #douyin-navigation');
    if (target && !(event.relatedTarget instanceof Node && target.contains(event.relatedTarget))) requestSync();
  }, { passive: true });
  document.addEventListener('loadeddata', requestSync, true);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
