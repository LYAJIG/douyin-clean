/* Independent settings implementation; see SOURCE-MAPPING.md for BewlyCat references. */
(() => {
  'use strict';
  const defaults = {
    schemaVersion: 3,
    alwaysUseDock: true, dockPosition: 'left', autoHideDock: false, halfHideDock: false,
    dockItemsConfig: {精选:true,推荐:true,搜索:true,关注:true,朋友:true,通知:false,消息:true,我的:true},
    dockOrder:['精选','推荐','搜索','关注','朋友','通知','消息','我的'],
    homeCategoriesConfig:{全部:true,公开课:true,游戏:true,二次元:false,音乐:true,影视:false,美食:true,知识:true,小剧场:false,生活vlog:true,体育:false,旅行:false,亲子:false,动物:false,三农:false,汽车:false,美妆穿搭:false},
    gridColumns: {base:3,sm:3,md:3,lg:3,xl:3,xxl:3},
    enableVideoPreview: true, enableVideoCtrlBarOnVideoCard: true, videoCardTitleFontSize: 'base',
    enableTopBar: true, otherPageTopBarConfig: 'scroll',
    showVideoPipButton:true, customFullscreenWheelVolume:false, fullscreenWheelVolumeStep:5,
  };
  const bools=Object.keys(defaults).filter(key=>typeof defaults[key]==='boolean');
  const enums={dockPosition:['left','right','bottom'],videoCardTitleFontSize:['xs','sm','base','lg'],otherPageTopBarConfig:['always','scroll','hover']};
  const clamp=(v,a,b,fallback)=>Number.isFinite(Number(v))?Math.max(a,Math.min(b,Math.round(Number(v)))):fallback;
  function normalize(raw) {
    const result=structuredClone(defaults);
    if(!raw || typeof raw!=='object' || Array.isArray(raw)) return result;
    for(const key of bools)if(typeof raw[key]==='boolean')result[key]=raw[key];
    for(const [key,values] of Object.entries(enums))if(values.includes(raw[key]))result[key]=raw[key];
    for(const key of Object.keys(result.gridColumns))if(raw.gridColumns && Object.hasOwn(raw.gridColumns,key))result.gridColumns[key]=clamp(raw.gridColumns[key],1,12,3);
    for(const key of Object.keys(result.dockItemsConfig))if(typeof raw.dockItemsConfig?.[key]==='boolean')result.dockItemsConfig[key]=raw.dockItemsConfig[key];
    for(const key of Object.keys(result.homeCategoriesConfig))if(typeof raw.homeCategoriesConfig?.[key]==='boolean')result.homeCategoriesConfig[key]=raw.homeCategoriesConfig[key];
    const order=Array.isArray(raw.dockOrder)?raw.dockOrder:[];
    result.dockOrder=[...new Set([...order.filter(key=>Object.hasOwn(result.dockItemsConfig,key)),...defaults.dockOrder])];
    if(!Object.values(result.dockItemsConfig).some(Boolean))result.dockItemsConfig.精选=true;
    if(result.autoHideDock)result.halfHideDock=false;
    result.fullscreenWheelVolumeStep=clamp(raw.fullscreenWheelVolumeStep,1,50,5);
    if (!Number.isFinite(raw.schemaVersion) || raw.schemaVersion < 2) result.enableTopBar=true;
    return result;
  }
  function columns(settings,width) {
    const points=[['xxl',1536],['xl',1280],['lg',1024],['md',768],['sm',640],['base',0]];
    return settings.gridColumns[points.find(([,min])=>width>=min)?.[0]||'base'];
  }
  globalThis.DYSettings={defaults,normalize,columns};
})();
