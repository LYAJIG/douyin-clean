# 抖音清爽 · 干净版

Chrome 和 Edge 的抖音网页扩展。点击浏览器工具栏中的扩展图标，打开分组设置弹窗。总开关暂停当前的调整，重新启用时会恢复已勾选的项目。

3.2.0 提供 81 个可独立打开的隐藏选项，涵盖顶栏、左侧导航、精选分类、头像菜单、卡片预览、播放器右侧和底部。弹窗可按名称或分组筛选设置。新选项默认关闭，沿用同一扩展目录升级时保留 3.0.0 的勾选状态。部分选项仅在对应入口出现时生效，抖音的界面版本和登录状态会影响入口是否存在。

## 安装

解压安装包。在 Chrome 打开 `chrome://extensions`，或在 Edge 打开 `edge://extensions`。启用开发者模式，点击「加载未打包的扩展程序」，选择直接包含 `manifest.json` 的文件夹。试用时请先关闭旧版「抖音清爽」和同类油猴脚本，再刷新抖音网页。

## 来源与反馈

本次重做参考 insin 的 [Control Panel for Twitter](https://github.com/insin/control-panel-for-twitter/blob/master/options.js)，采用分组设置、总开关和逐项保存的交互方式。抖音设置界面、显隐规则和验证由 Codex 协助实现。历史版本源于 ROOOOOYczx 的 [Better-Web-Tiktok](https://github.com/ROOOOOYczx/Better-Web-Tiktok)，并参考过 [BewlyCat](https://github.com/keleus/BewlyCat)。

问题可以通过 [GitHub Issues](https://github.com/LYAJIG/douyin-clean/issues) 反馈。请附上页面类型、失效的开关名称和复现步骤。


打开对应页面或菜单后，可在弹窗检查扩展是否已连接、已开启项是否匹配当前页面。新版播放器的控件结构参考了 [网页抖音体验增强](https://github.com/Frequenk/douyin-enhancer-userscript/blob/master/douyin-enhancer.user.js)。

3.2.0 新增抖音标志和侧栏活动开关，并为精选缩略图恢复按窗口宽度自定义列数。启用自定义列数后，默认从窄到宽为 3、3、3、4、5、6。直播域名共享顶栏和侧栏设置，以及全部、音乐、游戏、二次元的分类开关。设置弹窗的每组都有独立边框和标题区。

3.2.1 补充无文字侧栏图标、侧栏活动入口和卡片预览「稍后再看」的识别。
