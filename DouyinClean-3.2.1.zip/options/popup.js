'use strict';

(() => {
  const form = document.getElementById('settings');
  const status = document.getElementById('status');
  const filter = document.getElementById('filter');
  const empty = document.getElementById('empty');
  const pageStatus = document.getElementById('page-status');
  let statusRequest = 0;
  const controls = new Map();
  let values;
  let saveNumber = 0;

  function addOption(parent, id, text) {
    const label = document.createElement('label');
    const name = document.createElement('span');
    name.textContent = text;
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.name = id;
    input.disabled = true;
    const match = document.createElement('small');
    match.className = 'match-state';
    match.hidden = true;
    name.append(match);
    label.append(name, input);
    parent.append(label);
    controls.set(id, input);
  }

  async function checkPage() {
    const request = ++statusRequest;
    let report;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id != null) report = await chrome.tabs.sendMessage(tab.id, { type: 'douyin-clean-status' });
    } catch {
      // Chrome returns no receiver when the active tab has no content script.
    }
    if (request !== statusRequest || !values) return;
    pageStatus.textContent = report
      ? '已连接抖音。先展开菜单或播放器，再查看各项状态。'
      : '当前标签页未连接。请切到抖音并刷新网页。';
    const matched = new Set(report?.matched);
    const active = new Set(report?.active);
    for (const [id, input] of controls) {
      const state = input.parentElement.querySelector('small');
      if (!state) continue;
      state.hidden = !report || !active.has(id);
      state.textContent = matched.has(id) ? '已匹配' : '当前页面未找到';
    }
  }

  function render() {
    const enabled = values[CleanSettings.storageKey('enabled')] === true;
    for (const [id, input] of controls) {
      if (input.type === 'number') {
        if (input !== document.activeElement) input.value = CleanSettings.columnValue(values[CleanSettings.storageKey(id)], Number(input.defaultValue));
        input.disabled = !enabled || values[CleanSettings.storageKey('customColumns')] !== true;
      } else {
        input.checked = values[CleanSettings.storageKey(id)] === true;
        input.disabled = id !== 'enabled' && !enabled;
      }
    }
  }

  function addGroupTitle(group, text) {
    const title = document.createElement('h2');
    title.textContent = text;
    group.setAttribute('aria-label', text);
    group.append(title);
  }

  addOption(form, 'enabled', '启用扩展');
  const layout = document.createElement('fieldset');
  addGroupTitle(layout, '精选缩略图');
  addOption(layout, 'customColumns', '自定义每行视频数');
  for (const { width, count, id } of CleanSettings.breakpoints) {
    const label = document.createElement('label');
    const name = document.createElement('span');
    name.textContent = width ? '窗口宽度 ≥ ' + width + ' px' : '窗口宽度 < 640 px';
    const input = document.createElement('input');
    Object.assign(input, { type: 'number', name: id, min: 1, max: 8, step: 1, defaultValue: count, disabled: true });
    label.append(name, input);
    controls.set(id, input);
    layout.append(label);
  }
  form.append(layout);
  for (const group of CleanSettings.groups) {
    const fieldset = document.createElement('fieldset');
    addGroupTitle(fieldset, group.label);
    for (const { id, name } of group.options) addOption(fieldset, id, '隐藏' + name);
    form.append(fieldset);
  }

  filter.addEventListener('input', () => {
    const query = filter.value.trim().toLowerCase();
    let matches = 0;
    for (const section of form.querySelectorAll('fieldset')) {
      const groupMatches = section.querySelector('h2').textContent.toLowerCase().includes(query);
      for (const label of section.querySelectorAll('label')) {
        label.hidden = !groupMatches && !label.textContent.toLowerCase().includes(query);
        if (!label.hidden) matches++;
      }
      section.hidden = !section.querySelector('label:not([hidden])');
    }
    empty.hidden = matches !== 0;
  });
  form.addEventListener('submit', event => event.preventDefault());
  form.addEventListener('change', async event => {
    const input = event.target;
    if (!values || controls.get(input.name) !== input) return;
    const key = CleanSettings.storageKey(input.name);
    const request = ++saveNumber;
    const value = input.type === 'number'
      ? CleanSettings.columnValue(input.value, values[key])
      : input.checked;
    if (input.type === 'number') input.value = value;
    try {
      await chrome.storage.local.set({ [key]: value });
      if (request === saveNumber) status.textContent = '已保存';
    } catch {
      if (request === saveNumber) status.textContent = '保存失败，请重试';
      render();
    }
  });
  window.setInterval(checkPage, 2500);
  CleanSettings.watch(saved => {
    values = saved;
    render();
    checkPage();
  }).catch(() => { status.textContent = '无法读取设置，请重新打开弹窗'; });
})();

