'use strict';

(() => {
  const featuresAttribute = 'data-douyin-clean-features';
  const boundarySelector = 'button, a, [role="button"], [role="menuitem"], [role="switch"], xg-icon, dy-icon';
  const matchAttribute = 'data-douyin-clean-match';
  const labelSelector = 'button, a, [role="button"], [role="menuitem"], [role="switch"], [aria-label], [title], span, p, div';
  const excludedPlayer = '[data-e2e="comment-list"], #merge-all-comment-container, .discover-video-card-item, .bigCardQuickPlayerContainer';
  const profileAnchors = ['我的喜欢', '我的收藏', '观看历史', '退出登录'];
  const changingPlayerText = '.xgplayer-time, .xgplayer-progress, .danmaku, .danmakuContainer';
  let features = [];
  let groups = [];
  let marked = new Map();
  let positioned = new Set();
  const sidebarAnchoredMatches = new Map();
  let frame = 0;
  let values;
  let gridNodes = new Set();
  const gridOverrides = new Map();
  const gridProperties = ['display', 'grid-template-columns', 'gap', 'row-gap', 'column-gap'];
  const cardProperties = ['position', 'inset', 'top', 'right', 'bottom', 'left', 'transform', 'width', 'min-width', 'max-width', 'grid-area', 'grid-column', 'grid-row'];
  const isLive = location.hostname === 'live.douyin.com';

  const observer = new MutationObserver(records => {
    if (records.some(({ type, addedNodes, removedNodes, target, attributeName }) => {
      const element = target.nodeType === 1 ? target : target.parentElement;
      if (!element || element.closest(changingPlayerText)) return false;
      if (attributeName === 'style') return gridNodes.has(element) || gridNodes.has(element.parentElement);
      if (type === 'childList' && [...addedNodes, ...removedNodes].some(node => node.nodeType === 1)) return true;
      return groups.some(group => group.kind === 'profileMenu'
        ? element.closest('#douyin-header, [role="menu"], [role="menuitem"]') || findProfileMenu(element)
        : element.closest(group.scope));
    })) schedule();
  });

  function schedule() {
    if (!frame) frame = requestAnimationFrame(() => { frame = 0; scan(); });
  }

  function findProfileMenu(node) {
    for (let parent = node.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
      const text = parent.textContent;
      const anchors = profileAnchors.filter(label => text.includes(label)).length;
      if (anchors >= (parent.matches('[role="menu"]') ? 2 : 3)) {
        return parent.querySelector('#douyin-right-container, #douyin-navigation, video') ? null : parent;
      }
    }
    return null;
  }

  function normalized(text) {
    return text?.trim().replace(/\s+/g, ' ') || '';
  }

  function searchNames(node, allowText) {
    return [
      normalized(node.getAttribute('aria-label')),
      normalized(node.getAttribute('title')),
      allowText ? normalized(node.textContent) : '',
    ];
  }

  function matchTarget(node, scope, group, option) {
    if (group.kind === 'tabs') return node;
    const action = node.closest(boundarySelector);
    const names = new Set(option.names);
    let target = node;
    if (action && action !== scope && scope.contains(action)) {
      const actionNames = searchNames(action, true);
      const hasOwnLabel = actionNames.slice(0, 2).some(name => names.has(name));
      const onlyMatchingText = names.has(actionNames[2]) || option.names.some(name =>
        actionNames[2].startsWith(name) && /^(?:[(（]?[\d万亿.+]+[)）]?|30天内)$/.test(actionNames[2].slice(name.length).trim()));
      if ((hasOwnLabel || onlyMatchingText) && !action.querySelector('[role="menu"], [role="dialog"]')) target = action;
    }
    if (group.kind === 'player') return target;
    // Text-only entries may wrap their icon, label and badge in a single div.
    for (let parent = target.parentElement; parent && parent !== scope; parent = parent.parentElement) {
      if (!names.has(normalized(parent.textContent)) || parent.querySelectorAll('button, a, [role="button"], [role="menuitem"], [role="switch"]').length > 1) break;
      target = parent;
    }
    return target;
  }

  function letGridCssOverride(node, properties, targets) {
    targets.add(node);
    for (const property of properties) {
      if (node.style.getPropertyPriority(property) !== 'important') continue;
      if (!gridOverrides.has(node)) gridOverrides.set(node, new Map());
      gridOverrides.get(node).set(property, node.style.getPropertyValue(property));
      node.style.removeProperty(property);
    }
  }

  function syncGrid() {
    const root = document.documentElement;
    const columns = /^\/jingxuan(?:\/|$)/.test(location.pathname) && !isLive
      ? CleanSettings.gridColumns(values, innerWidth) : null;
    const next = new Set();
    if (columns) {
      const parents = new Map();
      for (const card of document.querySelectorAll('.discover-video-card-item')) {
        const parent = card.parentElement;
        parents.set(parent, (parents.get(parent) || 0) + 1);
      }
      for (const [parent, count] of parents) {
        if (count >= 2 || parent.matches('.bigCardWaterfallContainer')) next.add(parent);
      }
    }
    for (const node of gridNodes) if (!next.has(node)) node.removeAttribute('data-douyin-clean-grid');
    for (const node of next) if (!node.hasAttribute('data-douyin-clean-grid')) node.setAttribute('data-douyin-clean-grid', '');
    const targets = new Set();
    for (const node of next) {
      letGridCssOverride(node, gridProperties, targets);
      for (const card of node.children) {
        if (card.matches('.discover-video-card-item')) letGridCssOverride(card, cardProperties, targets);
      }
    }
    for (const [node, properties] of gridOverrides) {
      if (targets.has(node)) continue;
      for (const [property, value] of properties) {
        if (!node.style.getPropertyValue(property)) node.style.setProperty(property, value, 'important');
      }
      gridOverrides.delete(node);
    }
    if (columns) root.style.setProperty('--douyin-clean-columns', columns);
    else root.style.removeProperty('--douyin-clean-columns');
    gridNodes = next;
  }

  function markLiveRegions() {
    const groups = [
      ['nav', 'a[href]', a => ['精选', '推荐', '关注', '朋友', '我的'].includes(normalized(a.textContent)), 3],
      ['category', 'a[href*="/categorynew/4_"]', a => ['聊天', '音乐', '游戏', '二次元', '舞蹈', '文化', '生活', '运动'].includes(normalized(a.textContent)), 3],
      ['header', 'input[placeholder*="搜索"]', input => input.placeholder.includes('感兴趣'), 1],
    ];
    for (const [kind, selector, predicate, minimum] of groups) {
      const attribute = 'data-douyin-clean-live-' + kind;
      if (document.querySelector('[' + attribute + ']')) continue;
      const nodes = [...document.querySelectorAll(selector)].filter(predicate);
      for (const node of nodes) {
        for (let parent = node.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
          const header = kind === 'header';
          if (header && !/投稿|通知|客户端/.test(parent.textContent)) continue;
          if (!header && nodes.filter(candidate => parent.contains(candidate)).length < minimum) continue;
          if (!parent.querySelector('video, #douyin-right-container')) parent.setAttribute(attribute, '');
          break;
        }
        if (document.querySelector('[' + attribute + ']')) break;
      }
    }
  }

  function findSidebarLogo(scope) {
    const first = scope.querySelector('.tab-discover, a[href="/jingxuan"], a[href="https://www.douyin.com/jingxuan"]');
    if (!first) return null;
    return [...scope.querySelectorAll('a[href], [role="link"]')].find(link => {
      if (link.contains(first) || !(link.compareDocumentPosition(first) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
      const href = link.getAttribute('href');
      return ['/', 'https://www.douyin.com/', 'https://www.douyin.com'].includes(href)
        && !normalized(link.textContent) && link.querySelector('svg, img');
    });
  }

  const sidebar = '#douyin-navigation, nav[aria-label="主导航"], [data-douyin-clean-live-nav]';
  const graphic = 'svg, img, canvas, [style*="background-image"]';
  const center = element => {
    const box = element.getBoundingClientRect();
    return { x: box.left + box.width / 2, y: box.top + box.height / 2, width: box.width, height: box.height };
  };

  // Capture the rows by their graphics. Several Douyin layouts render the
  // accessible label only in a tooltip after the mouse enters the icon.
  function findSidebarGraphics() {
    const nav = document.querySelector(sidebar);
    if (!nav) return [];
    const rows = [...nav.querySelectorAll('a, span, p, div')];
    const findLabel = text => rows.find(node => normalized(node.textContent) === text && node.getBoundingClientRect().height > 0);
    const first = findLabel('精选') || findLabel('推荐') || nav.querySelector('.tab-discover, .tab-recommend');
    const rail = first ? first.getBoundingClientRect() : nav.getBoundingClientRect();
    const x = rail.left + rail.width / 2;
    const icons = [...document.querySelectorAll(graphic)].filter(node => {
      if (node.parentElement?.closest(graphic)) return false;
      const box = center(node);
      return box.width >= 12 && box.width <= 72 && box.height >= 12 && box.height <= 72
        && Math.abs(box.x - x) <= 35;
    });
    const matches = [];
    if (first) {
      const logo = icons.find(node => {
        const box = center(node);
        return box.y >= 10 && box.y < Math.min(82, rail.top - box.height / 2)
          && box.width >= 20 && !node.closest('.tab-discover, .tab-recommend');
      });
      if (logo) matches.push(['logo', graphicTarget(logo, nav)]);
    }

    const mine = findLabel('我的');
    const live = findLabel('直播');
    if (mine && live) {
      const top = mine.getBoundingClientRect().bottom;
      const bottom = live.getBoundingClientRect().top;
      const campaign = icons.find(node => {
        const box = center(node);
        if (box.y < top + 8 || box.y > bottom - 12) return false;
        const target = graphicTarget(node, nav, true);
        const text = normalized(target.textContent);
        return !/^(?:直播|我的)$/.test(text)
          && (node.matches('img, canvas, [style*="background-image"]') || /烽烟破晓/.test(text));
      });
      if (campaign) matches.push(['campaign', graphicTarget(campaign, nav, true)]);
    }

    const footer = icons.filter(node => {
      const box = center(node);
      return box.y > innerHeight - 215 && (nav.contains(node) || !node.closest('main, article, #douyin-right-container'));
    }).sort((a, b) => center(a).y - center(b).y);
    const tools = footer.filter((node, index) => !index || center(node).y - center(footer[index - 1]).y >= 14);
    if (tools.length === 4 && center(tools[3]).y > innerHeight - 58
        && tools.slice(1).every((node, index) => {
          const gap = center(node).y - center(tools[index]).y;
          return gap >= 23 && gap <= 65;
        })) {
      for (const [index, id] of [[0, 'sideSettings'], [2, 'sideHelp'], [3, 'feedback']]) {
        matches.push([id, graphicTarget(tools[index], nav)]);
      }
    }
    for (const [id, node] of matches) {
      if (id === 'logo' || id === 'campaign') sidebarAnchoredMatches.set(id, { nav, node });
    }
    for (const [id, previous] of sidebarAnchoredMatches) {
      if (previous.nav !== nav || !previous.node.isConnected) {
        sidebarAnchoredMatches.delete(id);
      } else if (!matches.some(([key]) => key === id)
          && (id === 'logo' ? !first : !mine || !live)) {
        matches.push([id, previous.node]);
      }
    }
    return matches;
  }

  function graphicTarget(node, scope, allowCaption = false) {
    let result = node;
    for (let parent = node.parentElement; parent && parent !== scope && parent !== document.body; parent = parent.parentElement) {
      const box = center(parent);
      const text = normalized(parent.textContent);
      if (box.width > 98 || box.height > 94 || parent.querySelectorAll(graphic).length > 1
          || parent.querySelectorAll(boundarySelector).length > 1 || (text && !allowCaption)
          || (allowCaption && /我的|直播|朋友|关注/.test(text))) break;
      result = parent;
      if (parent.matches(boundarySelector)) break;
    }
    return result;
  }

  function findPreviewLater() {
    const results = new Set();
    for (const video of document.querySelectorAll('.discover-video-card-item video, .bigCardQuickPlayerContainer video')) {
      const card = video.closest('.discover-video-card-item') || video.closest('.bigCardQuickPlayerContainer');
      const videoBox = video.getBoundingClientRect();
      if (videoBox.width < 75 || videoBox.height < 55) continue;
      const box = card.getBoundingClientRect();
      const candidates = new Set();
      for (const icon of card.querySelectorAll('svg, [role="button"], button')) {
        if (icon.contains(video)) continue;
        const point = center(icon);
        if (point.width < 10 || point.width > 65 || point.height < 10 || point.height > 65
            || point.x < box.right - Math.min(box.width * .22, 60) || point.x > box.right
            || point.y < videoBox.top || point.y > videoBox.top + Math.min(videoBox.height * .28, 49)) continue;
        const target = graphicTarget(icon, card);
        if (/音量|静音|播放|更多|分享|小窗|音质/.test(searchNames(target, true).join(' '))) continue;
        candidates.add(target);
      }
      if (candidates.size === 1) results.add(candidates.values().next().value);
    }
    return results;
  }

  function scan() {
    if (values) syncGrid();
    if (isLive && groups.length) markLiveRegions();
    const next = new Map();
    const nextPositioned = new Set();
    const record = (node, id) => {
      if (!next.has(node)) next.set(node, new Set());
      next.get(node).add(id);
    };
    const sidebarFeatures = ['logo', 'campaign', 'sideSettings', 'sideHelp', 'feedback'];
    const addPositioned = (node, id) => { record(node, id); nextPositioned.add(node); };
    if (sidebarFeatures.some(id => features.includes(id))) {
      for (const [id, node] of findSidebarGraphics()) if (features.includes(id)) addPositioned(node, id);
    }
    if (features.includes('previewLater')) {
      for (const node of findPreviewLater()) addPositioned(node, 'previewLater');
    }
    for (const group of groups) {
      const byName = new Map(group.options.flatMap(option => option.names.map(name => [name, option])));
      const candidates = group.kind === 'tabs'
        ? '.semi-tabs-tab, [role="tab"]'
        : group.kind === 'profileMenu'
          ? 'span, p, a, button, [role="menuitem"], [role="switch"]'
          : labelSelector;
      for (const scope of document.querySelectorAll(group.scope)) {
        const mainPlayer = group.label.startsWith('播放器');
        for (const { id, selector } of group.options) {
          if (id === 'logo') {
            const logo = findSidebarLogo(scope);
            if (logo) record(logo, id);
          }
          if (!selector) continue;
          for (const node of scope.querySelectorAll(selector)) {
            if (!mainPlayer || !node.closest(excludedPlayer)) record(node, id);
          }
        }
        if (!byName.size) continue;
        for (const node of scope.querySelectorAll(candidates)) {
          if (mainPlayer && node.closest(excludedPlayer)) continue;
          if (group.kind === 'tabs' && node.parentElement.closest(candidates)) continue;
          const allowText = node.childElementCount <= 4;
          const option = searchNames(node, allowText)
            .map(name => byName.get(name) || byName.get(name.replace(/\s*[(（]\d+[)）]$/, '')))
            .find(Boolean);
          if (!option) continue;
          const boundary = group.kind === 'profileMenu' ? findProfileMenu(node) : scope;
          if (!boundary || node === boundary) continue;
          const target = matchTarget(node, boundary, group, option);
          record(target, option.id);
        }
      }
    }
    for (const node of marked.keys()) if (!next.has(node)) node.removeAttribute(matchAttribute);
    for (const [node, ids] of next) {
      const value = [...ids].join(' ');
      if (node.getAttribute(matchAttribute) !== value) node.setAttribute(matchAttribute, value);
    }
    for (const node of positioned) if (!nextPositioned.has(node)) node.removeAttribute('data-douyin-clean-positioned');
    for (const node of nextPositioned) node.setAttribute('data-douyin-clean-positioned', '');
    positioned = nextPositioned;
    marked = next;
  }

  function apply() {
    const root = document.documentElement;
    if (features.length) root.setAttribute(featuresAttribute, features.join(' '));
    else root.removeAttribute(featuresAttribute);
    const availableGroups = isLive ? [...CleanRules.groups, CleanRules.liveCategories] : CleanRules.groups;
    groups = availableGroups.map(group => ({
      ...group, options: group.options.filter(option => features.includes(option.id))
    })).filter(group => group.options.length);
    observer.disconnect();
    if (groups.length || CleanSettings.gridColumns(values, innerWidth)) {
      observer.observe(root, {
        childList: true, subtree: true, characterData: true,
        attributes: true, attributeFilter: ['aria-label', 'title', 'id', 'role', 'data-e2e', 'href', 'class', 'style']
      });
    }
    scan();
  }

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message?.type !== 'douyin-clean-status') return;
    scan();
    respond({
      matched: [...new Set([...marked.values()].flatMap(ids => [...ids]))],
      active: features,
    });
  });

  window.addEventListener('resize', schedule);
  document.addEventListener('pointerover', event => {
    if (features.includes('previewLater') && event.target instanceof Element
        && event.target.closest('.discover-video-card-item, .bigCardQuickPlayerContainer')) schedule();
  }, { passive: true });
  window.addEventListener('popstate', schedule);
  window.navigation?.addEventListener('currententrychange', schedule);

  CleanSettings.watch(saved => {
    values = saved;
    features = CleanSettings.activeFeatures(values);
    if (document.documentElement) apply();
    else document.addEventListener('DOMContentLoaded', apply, { once: true });
  }).catch(error => console.warn('[抖音清爽] 无法读取设置', error));
})();
