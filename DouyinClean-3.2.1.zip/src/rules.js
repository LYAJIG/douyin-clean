'use strict';

const CleanRules = (() => {
  const group = (label, scope, rows, kind) => ({
    label, scope, kind,
    options: rows.map(([id, name, selector, names]) => ({
      id, name, selector, names: names || (kind === 'tabs' ? [name] : [])
    })),
  });
  const groups = [
    group('顶栏', '#douyin-header, header, [role="banner"], [data-douyin-clean-live-header]', [
      ['upload', '投稿', '', ['投稿']],
      ['notifications', '通知', '[data-e2e="notification-button"]', ['通知']],
      ['messages', '消息', '[data-e2e="message-button"]', ['消息', '私信']],
      ['avatar', '我的头像', '[data-e2e="user-avatar"], button[aria-label="个人中心"]', ['个人中心', '我的头像']],
      ['search', '搜索栏', '[data-e2e="searchbar"], form[role="search"], :is(div, form):has(> input:is([type="search"], [data-e2e="searchbar-input"])):has(> button)'],
      ['searchHint', '搜索框占位提示', 'input:is([type="search"], [data-e2e="searchbar-input"], [placeholder*="搜索"])'],
      ['wallpaper', '壁纸', '.DTMq1izD', ['壁纸']],
      ['recharge', '充钻石', 'a[href*="douyin_recharge"]', ['充钻石', '充值抖币']],
      ['client', '客户端下载', 'a[href*="/download/pc/"]', ['客户端', '下载客户端', '下载抖音客户端', '下载抖音精选']],
    ]),
    group('左侧导航', '#douyin-navigation, nav[aria-label="主导航"], [data-douyin-clean-live-nav]', [
      ['logo', '左上角抖音标志', '[data-e2e="douyin-logo"], [data-e2e="nav-logo"], [data-e2e="logo"], a:has(img[alt="抖音"]), a[aria-label="抖音首页"]', ['抖音首页', '抖音Logo']],
      ['campaign', '侧栏活动入口', '[data-e2e="nav-campaign"], .tab-campaign, [data-e2e="nav-promotion"], [class*="campaignEntry"], [class*="CampaignEntry"]', ['烽烟破晓']],
      ['featured', '精选', '.tab-discover, a[href="/jingxuan"]', ['精选']],
      ['recommend', '推荐', '.tab-recommend', ['推荐']],
      ['following', '关注', '.tab-follow', ['关注']],
      ['friends', '朋友', '.tab-friend', ['朋友']],
      ['myPage', '我的', '.tab-user_self', ['我的']],
      ['ai', 'AI 抖音', '', ['AI抖音', 'AI 抖音']],
      ['live', '直播', '', ['直播']],
      ['cinema', '放映厅', '', ['放映厅']],
      ['series', '短剧', '', ['短剧']],
      ['games', '小游戏', '', ['小游戏']],
      ['sideSettings', '设置', '[data-e2e="nav-settings"], [data-e2e="sidebar-settings"]', ['设置', '抖音设置']],
      ['sideHelp', '帮助', '[data-e2e="nav-help"], [data-e2e="sidebar-help"]', ['帮助', '帮助中心', '使用帮助']],
      ['feedback', '意见反馈', 'a[href*="feedback"], [data-e2e*="feedback"]', ['反馈', '意见反馈']],
    ]),
    group('精选分类', '.discover-tab-container .semi-tabs-bar, [data-e2e="discover-tabs"]', [
      ['catAll', '全部'], ['catCourse', '公开课'], ['catGame', '游戏'],
      ['catAnime', '二次元'], ['catMusic', '音乐'], ['catFilm', '影视'],
      ['catFood', '美食'], ['catKnowledge', '知识'], ['catDrama', '小剧场'],
      ['catVlog', '生活vlog'], ['catSports', '体育'], ['catTravel', '旅行'],
      ['catFamily', '亲子'], ['catAnimals', '动物'], ['catRural', '三农'],
      ['catCars', '汽车'], ['catBeauty', '美妆穿搭'],
    ], 'tabs'),
    group('头像菜单', 'body', [
      ['menuLikes', '我的喜欢', '', ['我的喜欢']],
      ['menuFavorites', '我的收藏', '', ['我的收藏']],
      ['menuHistory', '观看历史', '', ['观看历史']],
      ['menuLater', '稍后再看', '', ['稍后再看']],
      ['menuWorks', '我的作品', '', ['我的作品']],
      ['creator', '创作者中心', '', ['创作者中心']],
      ['reservations', '我的预约', '', ['我的预约']],
      ['orders', '我的订单', '', ['我的订单']],
      ['logout', '退出登录', '', ['退出登录']],
      ['keepLogin', '保存登录信息', '', ['保存登录信息']],
    ], 'profileMenu'),
    group('卡片悬停预览', '.discover-video-card-item, .bigCardQuickPlayerContainer', [
      ['previewLater', '稍后再看', '.xgplayer-watch-later, [data-e2e="video-player-watch-later"], .douyin-player-watch-later, [class*="watchLater"], [class*="WatchLater"], [data-e2e*="watch-later"]', ['稍后再看', '添加到稍后再看', '已添加到稍后再看']],
      ['previewPip', '小窗播放', '.xgplayer-pip, .douyin-player-inpicture, .xgplayer-inpicture', ['小窗播放', '画中画']],
      ['previewVolume', '音量', '.xgplayer-volume, .douyin-player-volume', ['音量', '静音', '取消静音']],
      ['previewPlay', '播放／暂停', '.xgplayer-play, .douyin-player-play', ['播放', '暂停']],
      ['previewTime', '播放时间', '.xgplayer-time, .douyin-player-time'],
      ['previewProgress', '进度条', '.xgplayer-progress, .douyin-player-progress'],
    ], 'player'),
    group('播放器右侧', '#slidelist, [data-e2e="video-detail"], [data-e2e="video-player"]', [
      ['like', '点赞', '[data-e2e="video-player-like"], [data-e2e="video-player-digg"]', ['点赞', '取消点赞']],
      ['collect', '收藏', '[data-e2e="video-player-collect"]', ['收藏', '取消收藏']],
      ['comment', '评论', '[data-e2e="video-player-comment"]', ['评论']],
      ['share', '分享', '[data-e2e="video-player-share"]', ['分享']],
      ['listen', '听抖音', '[data-e2e="video-player-listen"]', ['听抖音']],
      ['more', '更多菜单', '[data-e2e="video-player-more"], .D0ZulesG > .h283LqYY.eVgBybGY', ['更多', '更多操作']],
      ['previous', '上一条', '[data-e2e="video-switch-prev-arrow"]', ['上一条视频', '上一个视频']],
      ['next', '下一条', '[data-e2e="video-switch-next-arrow"]', ['下一条视频', '下一个视频']],
      ['nextEpisode', '下一集', '.tsSlqyY1', ['下一集']],
      ['recognition', '识别画面', '.txmGYPBp', ['识别画面']],
    ], 'player'),
    group('播放器底部', '#slidelist, [data-e2e="video-detail"], [data-e2e="video-player"], .xgplayer-controls, .douyin-player-controls, .douyin-player-controls-right', [
      ['play', '播放／暂停', '.xgplayer-play, .douyin-player-play', ['播放', '暂停']],
      ['time', '播放时间', '.xgplayer-time, .douyin-player-time'],
      ['progress', '进度条', '.xgplayer-progress, .douyin-player-progress'],
      ['danmaku', '弹幕开关', '[data-e2e="danmaku-switch"], .xgplayer-danmu', ['开启弹幕', '关闭弹幕']],
      ['danmakuSettings', '弹幕设置', '[data-e2e="danmaku-setting"]', ['弹幕设置']],
      ['danmakuInput', '弹幕输入框', '.danmakuContainer, [data-e2e="danmaku-input"]'],
      ['continuous', '连播', '[data-e2e="video-player-autoplay"], .automatic-continuous', ['连播']],
      ['clearScreen', '清屏', '[data-e2e="video-player-clear-screen"], .immersive-switch', ['清屏']],
      ['quality', '清晰度', '.xgplayer-definition, .xgplayer-setting-resolution, .douyin-player-playclarity-setting', ['清晰度']],
      ['speed', '倍速', '.xgplayer-playbackrate, .xgplayer-setting-playbackRatio, .douyin-player-playback-setting, .xgplayer-playback-setting', ['倍速']],
      ['later', '稍后再看', '.xgplayer-watch-later, [data-e2e="video-player-watch-later"], .douyin-player-watch-later', ['稍后再看']],
      ['pip', '小窗播放', '.xgplayer-pip, .douyin-player-inpicture, .xgplayer-inpicture', ['小窗播放', '画中画']],
      ['volume', '音量', '.xgplayer-volume, .douyin-player-volume', ['音量', '静音', '取消静音']],
      ['fullscreen', '全屏', '.xgplayer-fullscreen, .douyin-player-fullscreen', ['全屏', '退出全屏']],
    ], 'player'),
  ];
  // The public live directory uses a separate set of category links.
  const liveCategories = group('直播分类', '[data-douyin-clean-live-category]', [
    ['catAll', '全部', 'a[href="/"], a[href="https://live.douyin.com/"]'],
    ['catMusic', '音乐', 'a[href$="/categorynew/4_102"]'],
    ['catGame', '游戏', 'a[href$="/categorynew/4_103"]'],
    ['catAnime', '二次元', 'a[href$="/categorynew/4_104"]'],
  ]);
  return { groups, liveCategories };
})();
