'use strict';

const CleanSettings = (() => {
  const prefix = 'douyinClean3.';
  const groups = CleanRules.groups;
  const keys = ['enabled', ...groups.flatMap(group => group.options.map(({ id }) => id))];
  const storageKey = id => prefix + id;
  const breakpoints = [
    [0, 3], [640, 3], [768, 3], [1024, 4], [1280, 5], [1536, 6]
  ].map(([width, count]) => ({ width, count, id: 'columns' + width }));
  const defaults = Object.fromEntries([
    ...keys.map(id => [storageKey(id), id === 'enabled']),
    [storageKey('customColumns'), false],
    ...breakpoints.map(({ id, count }) => [storageKey(id), count]),
  ]);
  function columnValue(value, fallback) {
    const count = Number(value);
    return Number.isInteger(count) && count >= 1 && count <= 8 ? count : fallback;
  }
  function gridColumns(values, width) {
    if (values[storageKey('enabled')] !== true || values[storageKey('customColumns')] !== true) return null;
    const { id, count } = breakpoints.filter(point => point.width <= width).at(-1);
    return columnValue(values[storageKey(id)], count);
  }

  function activeFeatures(values) {
    if (values[storageKey('enabled')] !== true) return [];
    return keys.slice(1).filter(id => values[storageKey(id)] === true);
  }

  function watch(listener) {
    const values = { ...defaults };
    const received = new Set();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      let changed = false;
      for (const [key, change] of Object.entries(changes)) {
        if (!Object.hasOwn(defaults, key)) continue;
        received.add(key);
        values[key] = change.newValue ?? defaults[key];
        changed = true;
      }
      if (changed) listener(values);
    });
    return chrome.storage.local.get(defaults).then(saved => {
      for (const key of Object.keys(defaults)) {
        if (!received.has(key)) values[key] = saved[key];
      }
      listener(values);
    });
  }

  return { groups, storageKey, activeFeatures, watch, breakpoints, columnValue, gridColumns };
})();

