const fs=require('fs'),path=require('path'),cp=require('child_process');
for(const directory of ['src','options'])for(const file of fs.readdirSync(directory))if(file.endsWith('.js')){
 const result=cp.spawnSync(process.execPath,['--check',path.join(directory,file)],{stdio:'inherit'});
 if(result.status)process.exit(result.status);
}
console.log('JavaScript syntax checks passed.');
